var searchIndex = [
    
    {
        "uri": "/manual/updateguide/update3_7.html",
        "title": "Arbor 3.7への更新",
        "tags": [],
        "description": "",
        "summary": "Arbor 3.6.x以前から3.7.0以降へアップデートする際に、コンパイルエラーや警告が発生する場合があります。 以下の項を確認の上、修正してくださ",
        "content": "Arbor 3.6.x以前から3.7.0以降へアップデートする際に、コンパイルエラーや警告が発生する場合があります。\n以下の項を確認の上、修正してください。\nIInputSlotのメンバー変更 メソッド名の\u0026quot;Input\u0026quot;を削除。\n   旧メンバー名 新メンバー名     SetInputBranch SetBranch   RemoveInputBranch RemoveBranch   GetInputBranch GetBranch   IsConnectedInput IsConnected    IOutputSlotのメンバー変更 メソッド名の\u0026quot;Output\u0026quot;を削除。\n   旧メンバー名 新メンバー名     AddOutputBranch AddBranch   RemoveOutputBranch RemoveBranch   GetOutputBranch GetBranch   IsConnectedOutput IsConnected    メソッドをプロパティに変更。\n   旧メンバー 新メンバー     GetOutputBranchCountメソッド branchCountプロパティ    RerouteSlotのメンバー変更 一部メンバーをObsoleteに変更。\n   Obsoleteメンバー 代替メンバー     SetInputBranch(branch) inputSlot.SetBranch(branch)   RemoveInputBranch(branch) inputSlot.RemoveBranch(branch)   GetInputBranch() inputSlot.GetBranch()   IsConnectedInput(branch) inputSlot.IsConnected(branch)   AddOutputBranch(branch) outputSlot.AddBranch(branch)   RemoveOutputBranch(branch) outputSlot.RemoveBranch(branch)   GetOutputBranchCount() outputSlot.branchCount   GetOutputBranch(index) outputSlot.GetBranch(index)   IsConnectedOutput(branch) outputSlot.IsConnected(branch)    Parameterのメンバー変更 一部メンバーをObsoleteに変更。\n   Obsoleteメンバー 代替メンバー     GetVariable\u0026lt;TVariable\u0026gt;(ref TVariable value) GetVariable\u0026lt;TVariable\u0026gt;(TVariable defaultValue) TryGetVariable\u0026lt;TVariable\u0026gt;(out TVariable)    "
    },
    {
        "uri": "/manual/updateguide/update3_6.html",
        "title": "Arbor 3.6への更新",
        "tags": [],
        "description": "",
        "summary": "Arbor 3.5.x以前から3.6.0以降へアップデートする際に、コンパイルエラーが発生する場合があります。 以下の項を確認の上、修正してください。 シ",
        "content": "Arbor 3.5.x以前から3.6.0以降へアップデートする際に、コンパイルエラーが発生する場合があります。\n以下の項を確認の上、修正してください。\nシーンオブジェクトを扱うFlexibleField FlexibleType型を使用していたところを、FlexibleSceneObjectTypeへ変更しました。\n以下のようなコードを自作スクリプトで書いているかを確認し、修正してください。\n1 2  //flexible.type == FlexibleType.Constant // エラー flexible.type == FlexibleSceneObjectType.Constant // このように修正    該当するFlexibleFieldクラス  FlexibleGameObject FlexibleComponent FlexibleTransform FlexibleRectTransform FlexibleRigidbody FlexibleRigidbody2D  asmdefのファイル名 Arbor.BuiltInBehaviours.asmdefのファイル名に誤植があったのを修正しました。\n Arbor.BuiltInBehaviours.asmdefを参照する自作asmdefを定義している場合は、名前をArbor.BuiltInBehavioursに修正してください。\n(Unity 2019.1以降でUse GUIDsを有効にしている場合は名前での参照ではないため、この修正の必要はありません)  また、この修正に伴って更新直後に１度だけ以前のasmdefが見つからないエラーが表示されることがありますが動作に問題はありません。\n"
    },
    {
        "uri": "/manual/extra/package.html",
        "title": "PackageManagerでの利用",
        "tags": [],
        "description": "",
        "summary": "PackageManagerからArborを利用する方法について説明します。 導入手順 Assets/Plugins/Arborフォルダを任意の",
        "content": "PackageManagerからArborを利用する方法について説明します。\n導入手順   Assets/Plugins/Arborフォルダを任意のフォルダにコピー\n（ここでは、配置したArborフォルダをArborパッケージフォルダと呼びます）\n  PackageManagerに登録する。\n登録するには以下の方法があります。\n PackageManagerウィンドウでの登録  PackageManagerウィンドウを開き、+ボタンから「Add package from disk\u0026hellip;」を選択。 Arborパッケージフォルダ内のpackage.jsonを選択。   manifest.jsonを直接変更  {プロジェクトフォルダ}/Packages/manifest.jsonをコードエディタで開く 以下ように\u0026quot;dependencies\u0026quot;へ\u0026quot;com.caitsithware.arbor\u0026quot;を追加      { \u0026#34;dependencies\u0026#34;: { \u0026#34;{その他のパッケージ}\u0026#34; : \u0026#34;{その他のパッケージ}\u0026#34;, \u0026#34;com.caitsithware.arbor\u0026#34;: \u0026#34;file:{Arborパッケージフォルダのパス}\u0026#34; } }  更新する場合はArborパッケージフォルダを一旦削除し最新版Arborフォルダを再配置するか、バージョンごとにArborパッケージフォルダを別途配置してください。  注意点   導入直後にArborEditorで意図しない動作や例外などが発生する場合は一度プロジェクトを開き直してください。\n  PackageManagerへ登録した後に Arborパッケージフォルダの配置場所を変更する場合は「導入手順 2.」のやり直しが必要です。\n  バージョン管理について\n PackageManagerウィンドウから登録した場合、manifest.jsonには絶対パスが書き込まれるため、ご注意ください。\nリポジトリ管理内にArborパッケージフォルダを配置し、manifest.jsonにはその相対パスを設定してください。 PackageManagerはgitにも対応していますが、このアセットをpublicなgitサーバーなどへ公開する行為はEULA違反となります。\ngitにパッケージ用リポジトリを作成する場合はリポジトリを非公開に設定し、パーソナルアクセストークンなどの機能を使用してアクセスするようにお願いいたします。    PackageManagerについての詳細はUnityマニュアル: PackageManagerを参照してください。\n  "
    },
    {
        "uri": "/manual/scripting/behaviourattribute/addbehaviourmenu.html",
        "title": "AddBehaviourMenu",
        "tags": [],
        "description": "",
        "summary": "挙動追加メニューでのパスを指定できる属性です。 スクリプトリファレンス : AddBehaviourMenu 使用例 スクリプト TestAddBehaviourMenuという名前で",
        "content": "挙動追加メニューでのパスを指定できる属性です。\nスクリプトリファレンス : AddBehaviourMenu\n使用例 スクリプト TestAddBehaviourMenuという名前でスクリプトを作成し、以下のコードを記入してください。\n1 2 3 4 5 6 7 8 9 10  using UnityEngine;\rusing System.Collections;\rusing System.Collections.Generic;\rusing Arbor;\r[AddBehaviourMenu(\u0026#34;ManualExample/TestAddBehaviourMenu\u0026#34;)]\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestAddBehaviourMenu : StateBehaviour\r{\r}    動作確認 ステートの「挙動追加」をクリックし、挙動追加メニューウィンドウで確認できます。\n\r "
    },
    {
        "uri": "/manual/dataflow/about-dataflow.html",
        "title": "データフローとは？",
        "tags": [],
        "description": "",
        "summary": "データフローとは、ノードの処理結果を他のノードに受け渡すためのデータの流れを言います。 データの入出力スロットを接続するとデータフローを活用で",
        "content": "データフローとは、ノードの処理結果を他のノードに受け渡すためのデータの流れを言います。\nデータの入出力スロットを接続するとデータフローを活用できます。\n例 組み込みスクリプトを使用した例では以下のようなデータフローが簡単に組めるようになっています。\n\r  InstantiateGameObjectでプレハブをインスタンス化。 インスタンス化したGameObjectを出力。 Rigidbody.GetでRigidbodyコンポーネントを取り出し。 AddForceRigidbodyで受け取ったRigidbodyに力を加える。  また、例ではArborFSMを使用していますが、BehaviourTreeでも同様にデータの受け渡しができます。\n参考リンク  StateBehaviour : InstantiateGameObject StateBehaviour : AddForceRigidbody Calculator : Rigidbody.Get  "
    },
    {
        "uri": "/manual/parametercontainer/addcomponent.html",
        "title": "ParameterContainerコンポーネントの追加",
        "tags": [],
        "description": "",
        "summary": "パラメータを扱うにはParameterContainerコンポーネントが必要です。 ParameterContainerコンポーネントの追加に",
        "content": "パラメータを扱うにはParameterContainerコンポーネントが必要です。\nParameterContainerコンポーネントの追加には以下のような方法があります。\nHierarchyウィンドウのCreateボタン  HierarchyウィンドウのCreateボタンをクリックするかウィンドウ内を右クリック Arbor/ParameterContainerを選択 ParameterContainerが追加されている状態のGameObjectが作成される  \r Inspectorウィンドウの”Add Component”ボタン  HierarchyウィンドウでParameterContainerを追加したいGameObjectを選択 Inspectorウィンドウの\u0026quot;Add Component\u0026quot;ボタンをクリック Arbor/ParameterContainerを選択 GameObjectにParameterContainerが追加される  \r "
    },
    {
        "uri": "/manual/statemachine/howtouse/addcomponent.html",
        "title": "ArborFSMコンポーネントの追加",
        "tags": [],
        "description": "",
        "summary": "ステートマシンを使用するにはArborFSMコンポーネントが必要です。 ArborFSMコンポーネントの追加には以下のような方法があります。 H",
        "content": "ステートマシンを使用するにはArborFSMコンポーネントが必要です。\nArborFSMコンポーネントの追加には以下のような方法があります。\nHierarchyウィンドウのCreateボタン  HierarchyウィンドウのCreateボタンをクリックするかウィンドウ内を右クリック Arbor/ArborFSMを選択 ArborFSMが追加されている状態のGameObjectが作成される。  \r ArborEditorウィンドウのツールバー  ArborEditorウィンドウを開き、ツールバーの「作成」ボタンをクリック ArborFSMを選択 ArborFSMが追加されている状態のGameObjectが作成される。  \r ArborEditorウィンドウの未選択メニュー  ArborEditorウィンドウを開き、グラフを未選択の時に表示されるメニューの「ArborFSM作成」ボタンをクリック ArborFSMが追加されている状態のGameObjectが作成される。  \r Inspectorウィンドウの”Add Component”ボタン  HierarchyウィンドウでArborFSMを追加したいGameObjectを選択 Inspectorウィンドウの”Add Component”ボタンをクリック Arbor/ArborFSMを選択。 GameObjectにArborFSMが追加される。  \r "
    },
    {
        "uri": "/manual/statemachine/about-statemachine.html",
        "title": "ステートマシンとは？",
        "tags": [],
        "description": "",
        "summary": "ステートマシンは、挙動を１つの状態として、条件によって状態を切り替えていく仕組みを言います。 Arborでは、ArborFSMコンポーネントを",
        "content": "ステートマシンは、挙動を１つの状態として、条件によって状態を切り替えていく仕組みを言います。\nArborでは、ArborFSMコンポーネントをGameObjectに追加することでステートマシンが使えるようになります。\n例：スイッチとライト スイッチと電灯を考えてみます。\n スイッチOFFならライトは消える。 スイッチONならライトが点く。 スイッチを条件として、ライトの状態が切り替わります。  ArborFSMで仮組すると以下のようになります。\n\r Destroyメッセージが送られてきた場合に爆発エフェクトを出し削除する挙動も仮組されています。\n詳しい解説は後程行います。\nノードの構成要素 ステートマシンで使用するノードは以下のページにまとまっています。\nノードの構成要素\n各部位の解説の前に、一度参照してください。\n例の解説 では、先ほどの例をもう一度見てみましょう。\n\r  Light Offステート\n\r  まず、開始ステートのLight Offステートから始まる。 ActivateGameObectにより、Spotlightオブジェクトが非アクティブに変更される。\nArborリファレンス : ActivateGameObject OnTriggerEnterTransitionにより、Playerタグのオブジェクトが入ったらLight Onステートに遷移する。\nArborリファレンス : OnTriggerEnterTransition\n(OnTriggerEnterTransitionを使用するには、ArborFSMのあるGameObjectにColliderなどの設定が必要です)   Light Onステート\n\r  ActivateGameObectにより、Spotlightオブジェクトがアクティブに変更される。 OnTriggerExitTransitionにより、Playerタグのオブジェクトが出たらLight Offステートに遷移する。\nArborリファレンス : OnTriggerExitTransition\n(OnTriggerExitTransitionを使用するには、ArborFSMのあるGameObjectにColliderなどの設定が必要です)   Wait Triggerステート\n\r  常駐ステートなので、どのステートが実行されているかにかかわらず常時実行される。 TriggerTransitionにより、Destroyメッセージが来たらExplosion \u0026amp; Destroyステートに遷移する。\nArborリファレンス : TriggerTransition  なお、Triggerメッセージを送るにはSendTriggerを使用します。\nArborリファレンス : SendTrigger\n他のFSMからSendTriggerを使用して、間接的に遷移命令を出す形式です。     Explosion \u0026amp; Destroyステート\n\r  InstantiateGameObjectにより、プレハブをインスタンス化。\nArborリファレンス : InstantiateGameObject\n(ここでは仮組のため空のままになっていますが、パーティクルなどを設定する想定です) DestroyGameObjectにより、LightFSMオブジェクト(自分自身のGameObject)を破棄。\nArborリファレンス : DestroyGameObject    状態に挙動を組み合わせ、遷移条件に合致したら遷移していく流れがわかったかと思います。\n今回のような簡単な例であれば直接MonoBehaviourを書いたほうが楽という方もいるかと思いますが、\n状態が複数入り乱れるようになった際、グラフ形式で視覚化できるのは大きな利点となるでしょう。\n"
    },
    {
        "uri": "/manual/behaviourtree/about-behaviourtree.html",
        "title": "ビヘイビアツリーとは？",
        "tags": [],
        "description": "",
        "summary": "ビヘイビアツリーは、挙動の優先順位や条件を明確にし制御しやすくするための木構造を言います。 Arborでは、BehaviourTreeコンポー",
        "content": "ビヘイビアツリーは、挙動の優先順位や条件を明確にし制御しやすくするための木構造を言います。\nArborでは、BehaviourTreeコンポーネントをGameObjectに追加することで、ビヘイビアツリーが使えるようになります。\n例: プレイヤーとの距離によって挙動が変わる敵 例えば、敵AIを考えてみましょう。\n 敵とプレイヤーとの距離が１０メートル以内なら近づく。 それ以外の時は決まった経路を移動する。  プレイヤーに近づく挙動は決まった経路を移動する挙動に比べて優先度が高いと言えます。\nArborのBehaviourTreeで仮組すると以下のようになります。\n\r 左のノードほど優先度が高く、右に行くにつれ優先度が低くなります。\nまた、Decoratorと呼ばれるスクリプトをノードに追加することで条件判定を行い、実行するノードを制御しています。\n詳しい解説は後程行います。\nノードの構成要素 ビヘイビアツリーで使用するノードは以下のページにまとまっています。\nノードの構成要素\n各部位の解説の前に、一度参照してください。\n例の解説 では、先ほどの例をもう一度見てみましょう。\n\r  まずルートノードからはじまります。 Selectorノードにより、子ノードの成功ノードを探して左から順に実行していきます。\n\r  Agent Move To Transformノードでは、ParameterCheckデコレータが追加されているため、Parameterを条件に判定が行われます。\n\r  例として、プレイヤーとの距離はDistanceパラメータに格納しているものと仮定して作成しています。\n\r  仮にDistanceが15だったとすると、ParameterCheckデコレータがfalseを返すため、Agent Move To Transformノードは失敗になり、Selectorに戻ります。 SelectorはAgent Move To Transformノードが失敗したため、次のAgent Move On Waypointノードを実行します。\n\r  Agent Move On Waypointアクションは、TypeがCycleになっているため中断などが起きない限り繰り返し実行し続けます。 ここで、Distanceパラメータを10以下にしてみましょう。\n\r  Agent Move To TransformノードのParameterCheckの条件に合致するため、現ノードを中断して割り込みします。\n\r  再びDistanceパラメータを10より大きくすると、Agent Move To Transformノードが中断されAgent Move On Waypointノードがアクティブになるのが確認できます。\n\rDistanceパラメータによってアクティブノードが変わる様子\n\r   このように、右に行くほど実行優先度が低くなり、また優先度が高いノードのDecoratorにより割り込みなどができるのがわかったかと思います。\n今回のような簡単な例であれば有限ステートマシンでも特に複雑にならずに組めますが、\nステートの数が多く条件が複雑化しそうな場合ではビヘイビアツリーの方が、遷移線が交差することもなく実行ノード側に条件が記述できるためメンテナンスしやすい状態遷移が組めるようになります。\n"
    },
    {
        "uri": "/manual/arboreditor/openwindow.html",
        "title": "ArborEditorウィンドウを開く",
        "tags": [],
        "description": "",
        "summary": "Windowを直接開く メニューの「Window \u0026gt; Arbor \u0026gt; Arbor Editor」を選択 グラフから開く グラフを持ったGameObjectを選択。 Inspe",
        "content": "Windowを直接開く  メニューの「Window \u0026gt; Arbor \u0026gt; Arbor Editor」を選択\n\r   グラフから開く  グラフを持ったGameObjectを選択。 Inspectorウィンドウの「Open Editor」ボタンをクリック。\n\r   各グラフを作成する方法については以下を参照してください。\n ArborFSMコンポーネントの追加 BehaviourTreeコンポーネントの追加  "
    },
    {
        "uri": "/manual/arboreditor/nodes/comment.html",
        "title": "コメントノード",
        "tags": [],
        "description": "",
        "summary": "コメントを残すためのノードです。 作成方法 コメントノードを作成する位置を右クリック。 「コメント作成」を選択。",
        "content": "\r コメントを残すためのノードです。\n作成方法  コメントノードを作成する位置を右クリック。 「コメント作成」を選択。  \r "
    },
    {
        "uri": "/manual/scripting/behaviourtree/actionbehaviour.html",
        "title": "ActionBehaviour",
        "tags": [],
        "description": "",
        "summary": "ActionBehaviourのスクリプトを作成し、行いたい処理を記述することでオリジナルのアクションを追加できます。 ActionBehav",
        "content": "ActionBehaviourのスクリプトを作成し、行いたい処理を記述することでオリジナルのアクションを追加できます。\nActionBehaviourスクリプトファイルの作成  Projectウィンドウから作成したい場所で右クリック。 右クリックメニューから、「Create \u0026gt; Arbor \u0026gt; BehaviourTree \u0026gt; ActionBehaviour C# Script」を選択。\n\r  ファイル名を入力して決定  呼び出される関数 作成したActionBehaviourをBehaviourTreeグラフに追加すると、スクリプトの各関数が呼びだされるようになります。\n OnAwake\n初めてアクションノードがアクティブになった時に呼ばれます。 OnStart\nアクションノードがアクティブになった時に呼ばれます。 OnExecute\nアクションノードが実行される時に呼ばれます。\n実行タイミングについては、BehaviourTreeのUpdateSettingsとExecutionSettingsを参照してください。\nArborリファレンス : BehaviourTree OnAbort\nノードがDecoratorにより中断する時に呼ばれます。 OnEnd\nアクションノードが終了するときに呼ばれます。  注意点  MonoBehaviourのenabledは実行制御のために内部で使用しているため、代替となるbehaviourEnabledを使用してください。  呼び出し順 \r  OnEnableとOnDisable以外のMonoBehaviourのコールバックメソッドも使用できますが、Start()はOnExecute()の後に呼ばれてしまうため注意してください。  変数の宣言 \r 作成したスクリプトにpublicもしくはSerializedField属性をつけたフィールドを宣言することでArbor Editorで編集可能になります。\n1 2 3 4 5 6 7 8 9 10 11  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; using Arbor.BehaviourTree; [AddComponentMenu(\u0026#34;\u0026#34;)] public class TestActionBehaviour : ActionBehaviour { public string myName; // 略 }    実行の終了 OnExecuteメソッド内でFinishExecute(bool result)を呼び出すことで終了させられます。\n1 2 3 4  if (Input.GetKey(KeyCode.Space) ) { FinishExecute(true); }    データフロー ActionBehaviourではデータフローによる値の入出力が可能です。\n詳しくは、「スクリプティング : データフロー」を参照してください。\nスクリプティング : データフロー\n"
    },
    {
        "uri": "/manual/behaviourtree/howtouse/addcomponent.html",
        "title": "BehaviourTreeコンポーネントの追加",
        "tags": [],
        "description": "",
        "summary": "ビヘイビアツリーを使用するにはBehaviourTreeコンポーネントが必要です。 BehaviourTreeコンポーネントの追加には以下のよ",
        "content": "ビヘイビアツリーを使用するにはBehaviourTreeコンポーネントが必要です。\nBehaviourTreeコンポーネントの追加には以下のような方法があります。\nHierarchyウィンドウのCreateボタン  HierarchyウィンドウのCreateボタンをクリックするかウィンドウ内を右クリック Arbor/BehaviourTreeを選択 BehaviourTreeが追加されている状態のGameObjectが作成される。  \r ArborEditorウィンドウのツールバー  ArborEditorウィンドウを開き、ツールバーの「作成」ボタンをクリック BehaviourTreeを選択。 BehaviourTreeが追加されている状態のGameObjectが作成される。  \r ArborEditorウィンドウの未選択メニュー  ArborEditorウィンドウを開き、グラフを未選択の時に表示されるメニューの「BehaviourTree作成」ボタンをクリック BehaviourTreeが追加されている状態のGameObjectが作成される。  \r Inspectorウィンドウの”Add Component”ボタン  HierarchyウィンドウでBehaviourTreeを付けたいGameObjectを選択 Inspectorウィンドウの\u0026quot;Add Component\u0026quot;ボタンをクリック Arbor/BehaviourTreeを選択。 GameObjectにBehaviourTreeが追加される。  \r "
    },
    {
        "uri": "/manual/scripting/parameterreference/parameterreference.html",
        "title": "ParameterReference",
        "tags": [],
        "description": "",
        "summary": "ParameterReference関連クラスをフィールドに宣言することで、パラメータを参照できるようになります。 スクリプト例 1 2 3 4 5 6 7",
        "content": "ParameterReference関連クラスをフィールドに宣言することで、パラメータを参照できるようになります。\nスクリプト例 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15  using UnityEngine;\rusing Arbor;\rpublic class TestParameterReference : MonoBehaviour\r{\rpublic IntParameterReference intParameter;\rvoid Start ()\r{\rif (intParameter.parameter != null)\r{\rDebug.Log(intParameter.parameter.name + \u0026#34; : \u0026#34; + intParameter.parameter.intValue);\r}\t}\r}    このスクリプトをGameObjectに追加すると以下のようになります。\n\r    フィールド名 説明     Container 参照するParameterContainerボタンをクリックするとConstantかDataSlotを選択可能。(ただし、Arborのノード用スクリプト以外でDataSlotは使用できません)   Parameter 参照するパラメータContainerのタイプをDataSlotにした場合は文字列での名前指定。    取得したParameterについては、スクリプトリファレンスを参照してください。\nスクリプトリファレンス : Parameter\nParameterReference関連クラス  IntParameterReference FloatParameterReference BoolParameterReference GameObjectParameterReference StringParameterReference Vector2ParameterReference Vector3ParameterReference QuaternionParameterReference RectParameterReference BoundsParameterReference ColorParameterReference TransformParameterReference RectTransformParameterReference RigidbodyParameterReference Rigidbody2DParameterReference ComponentParameterReference LongParameterReference AnyParameterReference\n(Variableパラメータの参照に使用します)  "
    },
    {
        "uri": "/manual/scripting/dataflow/outputslot.html",
        "title": "出力スロット",
        "tags": [],
        "description": "",
        "summary": "OutpotSlotIntなどの出力スロットを宣言することでデータ出力ができます。 スクリプト例 TestOutputSlotBehaviour",
        "content": "OutpotSlotIntなどの出力スロットを宣言することでデータ出力ができます。\nスクリプト例 TestOutputSlotBehaviourスクリプトファイルを作成し、以下のコードを記述してください。\n1 2 3 4 5 6 7 8 9 10 11 12 13  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestOutputSlotBehaviour : StateBehaviour\r{\rpublic OutputSlotInt outputSlot;\rpublic override void OnStateBegin()\r{\routputSlot.SetValue(Random.Range(100, 200));\r}\r}    このスクリプトをArborFSMのステートに追加すると以下のようになります。\n\r 出力スロットクラス  OutputSlotInt OutputSlotFloat OutputSlotBool OutputSlotGameObject OutputSlotString OutputSlotVector2 OutputSlotVector3 OutputSlotQuaternion OutputSlotRect OutputSlotBounds OutputSlotColor OutputSlotTransform OutputSlotRectTransform OutputSlotRigidbody OutputSlotRigidbody2D OutputSlotComponent OutputSlotLong OutputSlotCollider OutputSlotCollider2D OutputSlotCollision OutputSlotCollision2D OutputSlotRaycastHit OutputSlotRaycastHit2D OutputSlotUnityObject OutputSlotAny  "
    },
    {
        "uri": "/manual/scripting/statebehaviour.html",
        "title": "StateBehaviour",
        "tags": [],
        "description": "",
        "summary": "StateBehaviourをカスタマイズするには、StateBehaviour用のスクリプトファイルを作成し、行いたい処理を記述する必要が",
        "content": "StateBehaviourをカスタマイズするには、StateBehaviour用のスクリプトファイルを作成し、行いたい処理を記述する必要があります。\nStateBehaviourスクリプトファイルの作成  Projectウィンドウから作成したい場所で右クリック。 右クリックメニューから、「Create \u0026gt; Arbor \u0026gt; StateBehaviour C# Script」を選択。\n\r  ファイル名を入力して決定  呼び出される関数 作成したStateBehaviourをArborEditorにてステートに割り当てると、スクリプトの各関数が呼び出されるようになります。\n OnStateAwake\n初めてステートに遷移してきたときに呼ばれます。 OnStateBegin\nステートに遷移してきたときに呼ばれます。 OnStateUpdate\nArborFSMのUpdate()のタイミングで呼ばれます。\n毎フレーム呼ばれるかどうかはArborFSMのUpdate Settingsに依存。 OnStateLateUpdate\nArborFSMのLateUpdate()のタイミングで呼ばれます。\n毎フレーム呼ばれるかどうかはArborFSMのUpdate Settingsに依存。 OnStateEnd\nステートから離れるときに呼ばれます。 MonoBehaviourのメッセージ関数\n詳しくはUnity ScriptReferenceのMonoBehaviourのMessagesを参照してください。  注意点  MonoBehaviourのenabledは実行制御のために内部で使用しているため、代替となるbehaviourEnabledを使用してください。  呼び出し順 \r  OnStateAwake/OnStateBegin/OnStateUpdate/OnStateLateUpdate/OnStateEndはArbor Editorでのステートノードに追加されている上から順に呼ばれます。 MonoBehaviour関連はUnityによる実行順にしたがって呼び出されます。\n詳しくはUnity Manualの イベント関数の実行順 を参照してください。  変数とArbor Editor \r 作成したスクリプトにpublicもしくはSerializeField属性をつけた変数を宣言することでArbor Editorで編集可能になります。\n1 2 3 4 5 6 7 8  using UnityEngine; using System.Collections; using Arbor; public class TestBehaviour : StateBehaviour { public string myName; // 略 }    ステートの接続 \r フィールドの追加 作成したスクリプトにpublicもしくはSerializeField属性をつけたStateLinkを宣言することでArbor Editorで接続スロットが表示されるようになります。\n1 2 3 4 5 6 7 8  using UnityEngine; using System.Collections; using Arbor; public class TestBehaviour : StateBehaviour { public StateLink nextState; // 略 }    接続先への遷移 遷移したいタイミングでTransitionを呼ぶと遷移できます。\n1  Transition( nextState );    データフロー StateBehaviourではデータフローによる値の入出力が可能です。\n詳しくは、「スクリプティング : データフロー」を参照してください。\nスクリプティング : データフロー\n"
    },
    {
        "uri": "/manual/window/behaviourmenu.html",
        "title": "挙動選択ウィンドウ",
        "tags": [],
        "description": "",
        "summary": "挙動を選択するウィンドウ UI説明 検索バー 挙動の名前で検索できます。 グループ名 現在の階層のグループ名です。 挙動リスト 挙動のリストです。 グループ",
        "content": "\r挙動を選択するウィンドウ\n\r UI説明 検索バー \r 挙動の名前で検索できます。\nグループ名 \r 現在の階層のグループ名です。\n挙動リスト \r 挙動のリストです。\nグループ \r 挙動のグループです。\nクリックするとグループ内のリストを表示します。\n挙動 \r 挙動です。\nクリックすると挙動がノードに追加されます。\nヘルプボタン \r 挙動のヘルプボタンをクリックすると、ブラウザでリファレンスを開きます。\n"
    },
    {
        "uri": "/manual/subgraph/create-subgraph.html",
        "title": "サブグラフの作成",
        "tags": [],
        "description": "",
        "summary": "サブグラフを使用する際は、以下挙動スクリプトが付いたステートもしくはアクションを作成してください。 SubStateMachine 子にステートマシンを持ち、ノードがアクテ",
        "content": "サブグラフを使用する際は、以下挙動スクリプトが付いたステートもしくはアクションを作成してください。\nSubStateMachine \r 子にステートマシンを持ち、ノードがアクティブになった際に実行します。\n Arborリファレンス : SubStateMachine(StateBehaviour) Arborリファレンス : SubStateMachine(ActionBehaviour)  SubStateMachineReference \r プレハブなどの外部ステートマシンを、子ステートマシンとして実行します。\n Arborリファレンス : SubStateMachineReference(StateBehaviour) Arborリファレンス : SubStateMachineReference(ActionBehaviour)  SubBehaviourTree \r 子にビヘイビアツリーを持ち、ノードがアクティブになった際に実行します。\n Arborリファレンス : SubBehaviourTree(StateBehaviour) Arborリファレンス : SubBehaviourTree(ActionBehaviour)  SubBehaviourTreeReference \r プレハブなどの外部ビヘイビアツリーを、子ビヘイビアツリーとして実行します。\n Arborリファレンス : SubBehaviourTreeReference(StateBehaviour) Arborリファレンス : SubBehaviourTreeReference(ActionBehaviour)  "
    },
    {
        "uri": "/manual/getting-started/about-arbor.html",
        "title": "「Arbor 3: FSM &amp; BT Graph Editor」について",
        "tags": [],
        "description": "",
        "summary": "Unityで有限ステートマシンやビヘイビアツリーを使ってゲーム作りたい！ だけど、ゲームロジックに依存する挙動は自分でコーディングしたい！ そん",
        "content": "\r  Unityで有限ステートマシンやビヘイビアツリーを使ってゲーム作りたい！ だけど、ゲームロジックに依存する挙動は自分でコーディングしたい！ そんな時に使えそうな有限ステートマシンとビヘイビアツリーのグラフ編集ウィンドウと、\n作りたい挙動にあわせてスクリプトを書けるシンプルなグラフエディタアセットです。  有限ステートマシン(FSM)とは？  有限ステートマシンとは、ある状態での挙動と、その状態から別の状態へ遷移する仕組みです。 たとえば、スイッチと電灯。  スイッチと電灯にはONとOFFという状態があり、スイッチをONにすれば電灯もONになります。 スイッチは押せばONに切り替わり、再度押すとOFFに切り替わる挙動です。 電灯はONであれば明かりを灯す挙動になります。    \r 詳しくは「ステートマシン」を参照してください。\nビヘイビアツリー(BT)とは？  行動の優先度と行動を行う条件をセットで扱えるようにした挙動の木構造です。 たとえば、敵AIを考えてみましょう。  プレイヤーに近づく挙動はプレイヤーとの距離が近ければ行う。 それ以外の時は決まった経路を巡回する。 プレイヤーに近づく挙動は決まった経路を移動する挙動に比べて優先度が高いと言えます。    \r 詳しくは「ビヘイビアツリー」を参照してください。\n"
    },
    {
        "uri": "/manual/getting-started.html",
        "title": "はじめに",
        "tags": [],
        "description": "",
        "summary": "ここでは、Arbor 3についての基本的な概要や操作方法などについて説明します。 「Arbor 3: FSM \u0026amp; BT Graph Editor」について Unityで有限ス",
        "content": "\r ここでは、Arbor 3についての基本的な概要や操作方法などについて説明します。\n「Arbor 3: FSM \u0026amp; BT Graph Editor」について  Unityで有限ステートマシンやビヘイビアツリーを使ってゲーム作りたい！ だけど、ゲームロジックに依存する挙動は自分でコーディングしたい！ そんな時に使えそうな有限ステートマシンとビヘイビアツリーのグラフ編集ウィンドウと、\n作りたい挙動にあわせてスクリプトを書けるシンプルなグラフエディタアセットです。  詳しくは、「Arbor 3: FSM \u0026amp; BT Graph Editor」について を参照してください。\nArborの使用を開始する Arborを購入したら、Unityへインポートして使用できるようになります。\n詳しくは、Arborを使用するための準備を参照してください。\n次のステップへ  ArborEditorウィンドウ ArborEditorウィンドウについて説明しています。 ステートマシン ステートマシンについて説明しています。 ビヘイビアツリー ビヘイビアツリーについて説明しています。 ParameterContainerParameterContainerについて説明しています。 データフロー データスロットによるデータの受け渡しについて説明しています。  チュートリアル Arborの基本的な使い方を実践できるチュートリアルもあります。\nチュートリアル\n"
    },
    {
        "uri": "/manual/scripting/behaviourattribute/hidebehaviour.html",
        "title": "HideBehaviour",
        "tags": [],
        "description": "",
        "summary": "挙動追加メニューには表示しないようにする属性です。 スクリプトリファレンス : HideBehaviour 使用例 スクリプト TestHideBehaviourという名前でス",
        "content": "挙動追加メニューには表示しないようにする属性です。\nスクリプトリファレンス : HideBehaviour\n使用例 スクリプト TestHideBehaviourという名前でスクリプトを作成し、以下のコードを記入してください。\n1 2 3 4 5 6 7 8 9 10  using UnityEngine;\rusing System.Collections;\rusing System.Collections.Generic;\rusing Arbor;\r[HideBehaviour]\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestHideBehaviour : StateBehaviour\r{\r}    動作確認 ステートの「挙動追加」をクリックし、挙動追加メニューウィンドウで表示されていないのが確認できます。\n\r 指定しない場合であれば、Scriptsグループの中に１つだけTestHideBehaviourがあるはずですが、TestHideBehaviourが非表示になっているためScriptsグループも表示されなくなっています。\n"
    },
    {
        "uri": "/manual/dataflow/howtouse.html",
        "title": "データフローの使い方",
        "tags": [],
        "description": "",
        "summary": "データスロット 接続 データスロットのフィールドをドラッグ。 同じ型の対となるスロットにドロップ。 切断 接続ラインを右クリック。 「切断」を選択 FlexibleField Fl",
        "content": "データスロット 接続  データスロットのフィールドをドラッグ。 同じ型の対となるスロットにドロップ。  \r 切断  接続ラインを右クリック。 「切断」を選択  \r FlexibleField FlexibleField関連クラスのフィールドでは、複数の参照方法を選択できますので柔軟に値が設定できます。\n指定方法の選択  フィールド横のボタンをクリック。 タイプを選択。  \r 参照タイプ FlexibleType FlexibleVector3などで選択できるタイプ。\n\r    項目 内容     Constant 定数値。値を設定するフィールドが表示される。   Parameter パラメータを参照する。パラメータについては ParameterContainer を参照してください。   DataSlot データの入力スロット。    FlexiblePrimitiveType FlexibleIntなどの数値型で選択できるタイプ。\n\r    項目 内容     Constant 定数値。値を設定するフィールドが表示される。   Parameter パラメータを参照する。パラメータについては ParameterContainer を参照してください。   Random 指定範囲の中からランダムに取得する。   DataSlot データの入力スロット。    FlexibleSceneObjectType FlexibleGameObjectなどのシーンオブジェクト型で選択できるタイプ。\n\r    項目 内容     Constant 定数値。値を設定するフィールドが表示される。   Parameter パラメータを参照する。パラメータについては ParameterContainer を参照してください。   DataSlot データの入力スロット。   Hierarchy グラフの階層から参照する。Self自グラフを所有しているGameObjectを参照。RootGraphグラフの階層化をしている場合に、ルートグラフを所有しているGameObjectを参照。自グラフがルートの場合は、自グラフのGameObjectを参照する。ParentGraphグラフの階層化をしている場合に、親グラフのGameObjectを参照。自グラフがルートの場合はnullを返す。    ドラッグ＆ドロップによる設定 選択しているタイプに関係なく、ParameterやDataSlot（シーンオブジェクト型の場合はGameObjectやComponentも可）を直接ドラッグ＆ドロップして設定できます。\n 設定したいパラメータなどをドラッグ。 Dropフィールドへドロップ。  \r DataLink属性 DataLink属性を使用したフィールドでは、定数かデータフローからの入力が使用できます。\nまた、データフローから入力する場合はどのタイミングで値を更新するか指定できます。\nタイミングの指定  入力スロットを他の出力スロットへ接続すると、タイミング指定フィールドが表示される。 タイプを指定。 (表示されない場合はスクリプトによりタイミングが指定されているため変更できません。)  \r タイミングの種類 \r    項目 内容     Noting 更新しない。   Everything 常に更新する。   Enter ノードに入った時に更新する。   Execute ノードが実行される時に更新する。   Manual スクリプトから任意のタイミングに更新する。    リルートノード リルートノードを使用すると、データフローのラインを整理しやすくなります。\nリルートノードを作成して接続  データスロットのフィールドをドラッグ。 リルートノードを作成したいグラフ内の位置でドロップ メニューの”リルート”を選択  \r リルートノード挿入  接続ライン上のリルートノードを作成したい位置を右クリック。 メニューの”リルート”を選択。  \r リルートノードの方向変更  方向を変更するリルートノードを選択 表示される方向アイコンをドラッグして方向を変更。  \r 接続ラインについて 値表示 プレイ中に接続ラインをマウスオーバーすると、現在値が表示されます。\n\r また、接続ラインの右クリックメニューから「データ値を常に表示」を選択すると、マウスオーバーしなくても表示されるようになります。\n全ての接続ラインの値を表示したい場合は、ツールバーの「デバッグ」メニューから「すべてのデータ値を表示」を選択すると切り替わります。\n\r 右クリックメニュー 接続ライン上を右クリックすると、メニューが表示されます。\n\r    項目 内容     データ値を常に表示 プレイ時にデータ値を常に表示します。   リルート リルートノードを挿入します。   切断 切断します。    "
    },
    {
        "uri": "/manual/parametercontainer/editparameter.html",
        "title": "パラメータの編集",
        "tags": [],
        "description": "",
        "summary": "パラメータの追加 「Parameters」の＋ボタンをクリック。 追加したい型を選択。 パラメータの編集 名前、値を選択し編集。 パラメータの削除 パラ",
        "content": "パラメータの追加  「Parameters」の＋ボタンをクリック。\n追加したい型を選択。  \r パラメータの編集  名前、値を選択し編集。  \r パラメータの削除  パラメータを選択し、－ボタンをクリック。  \r パラメータの検索  検索バーに名前を入力して検索。\nまた検索タイプを選択することでタイプごとのフィルタリングができる。  \r "
    },
    {
        "uri": "/manual/statemachine/howtouse/opengraph.html",
        "title": "ArborFSMグラフを開く",
        "tags": [],
        "description": "",
        "summary": "ArborFSMを編集するにはArbor EditorウィンドウでArborFSMグラフを開く必要があります。 HierarchyウィンドウでA",
        "content": "ArborFSMを編集するにはArbor EditorウィンドウでArborFSMグラフを開く必要があります。\n HierarchyウィンドウでArborFSMコンポーネントが付いたGameObjectを選択。 InspectorウィンドウのArborFSMコンポーネントエディタの”Open Editor”ボタンをクリック。  \r また、すでにArbor Editorウィンドウが開いている場合はHierarchyウィンドウでArborFSMコンポーネントが付いたGameObjetを選択すると切り替わります。\n"
    },
    {
        "uri": "/manual/behaviourtree/nodes.html",
        "title": "ノードの構成要素",
        "tags": [],
        "description": "",
        "summary": "ルートノード ビヘイビアツリーを実行する際に一番最初にアクティブになるノードです。 １つの子ノードと接続できます。 コンポジットノード １つか複数の",
        "content": "ルートノード \r ビヘイビアツリーを実行する際に一番最初にアクティブになるノードです。\n１つの子ノードと接続できます。\nコンポジットノード \r １つか複数の子ノードを持ち、どの子ノードを実行するかの制御を行います。\nどのように制御するかはCompositeBehaviourスクリプトで記述されています。\nまた、後に説明するDecoratorスクリプトやServiceスクリプトを追加できます。\n組み込みCompositeBehaviour  Selector\n子ノードを左から順に実行し、子ノードが 成功を返した時点で終了 し成功を返します。\nすべての子ノードが失敗を返した場合は失敗を返します。\n左から順に成功ノードを探し、それ以降のノードは実行したくない場合に用います。 Sequencer\n子ノードを左から順に実行し、子ノードが 失敗を返した時点で終了 し失敗を返します。\nすべての子ノードが成功を返した場合は成功を返します。\n子ノードが成功を返す限りすべて実行させたい場合に用います。  組み込みCompositeBehaviourのリファレンスはこちらを参照してください。\nArborリファレンス : 組み込みCompositeBehaviour\nアクションノード \r アクションを実行するノードです。\nどのようなアクションを行うかはActionBehaviourスクリプトで記述します。\nまた、こちらもDecoratorスクリプトやServiceスクリプトを追加できるようになっています。\n組み込みActionBehaviourのリファレンスはこちらを参照してください。\nArborリファレンス : 組み込みActionBehaviour\nActionBehaviourスクリプトの作成についてはこちら。\nスクリプティング : ActionBehaviour\nDecoratorスクリプト \r 条件判定を行って実行中ノードの中断や割り込みを行ったり、終了するタイミングで繰り返し判定などを行えるスクリプトです。\nコンポジットノードやアクションノードに追加して使用します。\n組み込みDecoratorのリファレンスはこちらを参照してください。\nArborリファレンス : 組み込みDecorator\nDecoratorスクリプトの作成についてはこちら。\nスクリプティング : Decorator\nAbortFlagsについて 中断や割り込みの対象はAbortFlagsで制御します。\n Self\n自ノードもしくはその配下のノードが実行中に条件判定を行う。\n条件判定の結果がfalseである場合は中断し、親ノードへ失敗を返す。 LowerPriority\n自ノードよりも右にある低優先度のノードが実行中に条件判定を行う。\n条件判定の結果がtrueである場合は実行中ノードを中断し、自ノードがアクティブになる。  上記２つのフラグを組み合わせて設定できます。\nまた、AbortFlagsに関係なく自ノードがアクティブになる際に一度条件判定を行い、結果がfalseであればそのまま失敗として返します。\nServiceスクリプト Serviceスクリプトはコンポジットノードとアクションノードに追加でき、ノードがアクティブの間何かしらの処理を行えるスクリプトです。\n例のBehaviourTreeでは使用していませんが、\n例えばプレイヤーとの距離をParameterに格納するServiceをSelectorノードに追加するなど、補助的な処理を記述するのに適しています。\nServiceスクリプトの作成についてはこちら。\nスクリプティング : Service\n"
    },
    {
        "uri": "/manual/statemachine/nodes.html",
        "title": "ノードの構成要素",
        "tags": [],
        "description": "",
        "summary": "開始ステート ArborFSMが開始した際に一番初めに実行されるステートです。 １つのグラフに必ず１つ必要です。 ステート 通常のステートです。 開始",
        "content": "開始ステート \r ArborFSMが開始した際に一番初めに実行されるステートです。\n１つのグラフに必ず１つ必要です。\nステート \r 通常のステートです。\n開始ステートや他のステートから遷移することで実行されます。\n常駐ステート \r 実行中ノードがどれかにかかわらず常に実行されるステートです。\n何らかの割り込み判定などをここで行います。\nまた、常に実行されているため、常駐ステートから他のステートへの遷移は可能ですが、他のステートから常駐ステートへは遷移できません。\nリルートノード \r 接続ラインの経路を調整するためのノードです。\n接続ラインが交差して見にくい場合に使用します。\nラインの方向もこのノードで調整できます。\nStateBehaviourスクリプト \r ステートの挙動を処理するためのスクリプトです。\n開始ステートや通常ステート、常駐ステートのすべてに設定できます。\n１つのステートに複数のStateBehaviourを追加できるため、挙動を組み合わせて状態を作成できます。\nStateBehaviourスクリプトの作成についてはこちら。\nスクリプティング : StateBehaviour\n組み込みStateBehaviour 例に出ているActivateGameObjectやOnTriggerEnterTransitionなど、あらかじめ組み込まれている挙動もStateBehaviourスクリプトで記述されています。\n組み込みStateBehaviourのリファレンスはこちらを参照してください。\nArborリファレンス : StateBehaviours\nStateLinkについて \r 状態遷移を行うにはStateLinkを使用します。\nStateBehaviourにStateLinkフィールドを宣言すると、Arbor Editorにフィールドが表示されます。\n接続することで、実行時にStateBehaviourスクリプトの記述に従って状態遷移が行われます。\n操作方法    操作 方法     接続 ドラッグ＆ドロップ\n\r    切断 接続ラインを右クリックし「切断」を選択。\n\r     TransitionTiming 遷移するタイミングは即座に行われるのではなく、TransitionTimingの指定に従います。\nTransitionTimingはStateLinkの歯車アイコンをクリックすると開く設定ウィンドウによって行えます。\n\r TransitionTimingの動作は以下のようになります。\n   項目 内容     Late Update Overwrite LateUpdate時に遷移するよう予約する。\n同フレーム内で既に遷移予約されている場合は上書きする。   Immediate 遷移呼び出し時に瞬時に遷移する。\n遷移がループしている場合、無限ループする可能性もあるので使用には注意すること。   Late Update Dont Overwrite LateUpdate時に遷移するよう予約する。(デフォルト)\n同フレーム内で既に遷移予約されている場合は上書きしない。    "
    },
    {
        "uri": "/manual/arboreditor.html",
        "title": "ArborEditorウィンドウ",
        "tags": [],
        "description": "",
        "summary": "各種グラフを編集するためのウィンドウです。 ArborEditorウィンドウを開く ArborEditorウィンドウを開く方法について説明します",
        "content": "\r 各種グラフを編集するためのウィンドウです。\n ArborEditorウィンドウを開く\nArborEditorウィンドウを開く方法について説明します。 UI説明\nウィンドウの各UIについて説明します。 グラフ共通のノード\nグラフの種類に関係なく共通して使用できるノードについて説明します。 グラフ共通の使い方\n基本的な操作方法について説明します。  "
    },
    {
        "uri": "/manual/arboreditor/interface.html",
        "title": "UI説明",
        "tags": [],
        "description": "",
        "summary": "１．ツールバー 「 作成」ドロップダウン シーンに、選択したグラフを持つGameObjectを作成します。 メニュー 内容 ArborFSM ArborFSMを持つGa",
        "content": "\r １．ツールバー 「 作成」ドロップダウン \r シーンに、選択したグラフを持つGameObjectを作成します。\n   メニュー 内容     ArborFSM ArborFSMを持つGameObjectをシーンに作成   BehaviourTree BehaviourTreeを持つGameObjectをシーンに作成    グラフ選択フィールド \r グラフを選択するフィールドです。\n「ライブ追跡」トグル \r プレイ中にアクティブノードを追跡するか切り替えます。\n「表示」ドロップダウン \r 表示関連メニューを表示します。\n   メニュー 内容     全て展開 折りたたまれている挙動を全て展開する   全て折りたたみ 展開されている挙動をすべて折りたたむ   ノードコメント \r 通常ノードごとの設定に従って表示する。全て表示全てのノードコメントを表示する。コメント済みのみ表示書き込まれているノードコメントのみを表示する。全て非表示全てのノードコメントを非表示にする。   データスロット \r ノード外に表示ノードの枠外にデータスロットを表示する。ノード内に表示ノードの枠内にデータスロットを表示する。フレキシブルに表示常に表示せず接続するときなどのみノードの枠外にデータスロットを表示する。    「デバッグ」ドロップダウン \r 各グラフのデバッグ関連メニューを表示します。\n   メニュー 内容     常にすべてのデータ値を表示 個々のデータラインの表示設定によらず常にデータ値を表示する   すべてのデータ値を表示 プレイ中に全てのデータラインの出力値を表示に変更する   すべてのデータ値を非表示 全てのデータラインの出力値を非表示に変更する    グラフ別のメニュー項目は各グラフのマニュアルを参照してください。\n ステートマシンの使い方 ビヘイビアツリーの使い方  キャプチャボタン \r グラフビュー全体を画像に保存します。\n（最大サイズは16384 x 16384です）\n通知ボタン \r 新しいバージョンがリリースされた場合などに表示されます。\nヘルプボタン \r マニュアルなどを開くメニューが表示されます。\n設定ボタン \r 各種設定を行うウィンドウを表示します。\n   項目 内容     言語 表示する言語の選択 \r SystemOS設定に従って言語設定しますUnityEditorUnityEditorの設定に従って言語設定します(Unity2018.1以降)各言語各言語に設定します   ロゴ表示 グラフビューにArborロゴ表示の切り替え \r Hiddenロゴを非表示にしますFade Outロゴ表示後にフェードアウトしますAlways Show常にロゴを表示します   ズーム ズームアウトする量の設定(Unity2017.2以降)   マウスホイールの挙動 マウスホイールの挙動がズームかスクロールの選択(Unity2017.2以降) \r Zoomグラフのズームを変更しますScroolグラフをスクロールします   コメントのズーム影響 ノードコメントがズームの影響を受けるかどうかを設定(Unity2017.2以降)   ドッキングして開く ArborEditorウィンドウを開くときのドッキングの切り替え   階層のライブ追跡 ライブ追跡時、グラフ階層も追跡するかの切り替え   グリッド表示 グラフビューのグリッド表示の切り替え   グリッドにスナップ グラフビューでドラッグした際にスナップするかの切り替え   グリッドサイズ グラフビューで表示するグリッド幅の設定   グリッド分割数 グリッドサイズを何分割するかの設定   デフォルトのグリッド設定に戻す グリッド設定をデフォルトに戻す   バージョン インポートしているArborのバージョン    ２．サイドパネル サイドパネルのトグルボタン \r サイドパネルの表示を切り替えます。\nグラフタブ グラフの基本データについてのタブです。\nグラフ \r グラフ名の設定や親グラフや子グラフの切り替えボタンが表示されます。\n Name グラフ名の編集フィールド Parent Graph 親グラフをグラフビューに表示するボタン Children 子グラフをグラフビューに表示するボタン\n(SubStateMachineやSubBehaviourMachineがある場合に表示)  ノードリスト \r グラフに配置しているノードのリストが表示されます。 (表示されるノードは各グラフの状態にかかわるノードのみ)\n操作方法    操作 Windows Mac     選択 マウス左ボタン マウスボタン   追加選択 / 選択解除 Ctrl + マウス左ボタン command ⌘ + マウスボタン   連続したノード選択 Shift + マウス左ボタン shift ⇧ + マウスボタン    パラメータタブ グラフ内パラメータについてのタブです。\nParameterContainerの作成 グラフに直接紐づいたParameterContainerを作成します。\n パラメータタブを開き、「作成」ボタンをクリック。  \r パラメータの編集 ParameterContainerと同様にパラメータの編集ができます。\n詳しくは、ParameterContainerを参照してください。\n３．グラフビュー \r ノードグラフを表示します。\n４．グラフパス \r 現在グラフビューに表示されているグラフまでのパスを表示します。\n"
    },
    {
        "uri": "/manual/arboreditor/nodes/group.html",
        "title": "グループノード",
        "tags": [],
        "description": "",
        "summary": "複数のノードをまとめるためのノードです。 作成方法 グループノードを作成する位置を右クリック。 「グループ作成」を選択。 グループの移動 グループとし",
        "content": "\r 複数のノードをまとめるためのノードです。\n作成方法  グループノードを作成する位置を右クリック。 「グループ作成」を選択。  \r グループの移動  グループとしてまとめたいノードをグループノードの枠内に移動 グループノードをドラッグ\u0026amp;ドロップして移動  \r グループノードのみ移動  グループノードをAlt+ドラッグ(Macではoption ⌥ + ドラッグ)  \r 自動整列 グループノードの中にあるノードが重ならないように、縦方向もしくは横方向に自動調整する機能があります。\n 歯車アイコンをクリックし、設定を選択。 \u0026ldquo;Auto Alignment\u0026quot;を設定  \r "
    },
    {
        "uri": "/manual/scripting/behaviourtree/decorator.html",
        "title": "Decorator",
        "tags": [],
        "description": "",
        "summary": "Decoratorのスクリプトを作成し、行いたい処理を記述することでオリジナルの条件判定やループ処理を追加できます。 Decoratorスクリ",
        "content": "Decoratorのスクリプトを作成し、行いたい処理を記述することでオリジナルの条件判定やループ処理を追加できます。\nDecoratorスクリプトファイルの作成  Projectウィンドウから作成したい場所で右クリック。 右クリックメニューから、「Create \u0026gt; Arbor \u0026gt; BehaviourTree \u0026gt; Decorator C# Script」を選択。\n\r  ファイル名を入力して決定  呼び出される関数 作成したDecotarotをコンポジットノードやアクションノードに追加すると、スクリプトの各関数が呼びだされるようになります。\n OnAwake\n初めてノードがアクティブになった時に呼ばれます。 OnStart\nノードがアクティブになった時に呼ばれます。 OnAbort\nノードがDecoratorにより中断する時に呼ばれます。 OnEnd\nノードが終了するときに呼ばれます。 HasConditionCheck\nConditionCheckを行うかどうかを判定するために呼ばれます。\nConditionCheckを行わない場合はoverrideしてfalseを返すようにしてください。\nデフォルトtrue。 OnConditionCheck\n条件判定を行う時に呼ばれます。\n条件に合致する場合はtrueを、合致しなければfalseを返してください。\n中断するかどうかは最終的にはAbortFlagsにより決定されます。 OnRepeatCheck\nノードが正常終了した場合に繰り返すかどうかを判定する際に呼ばれます。\n繰り返す場合はtrueを返してください。\nデフォルトfalse OnFinishExecute\n実行結果を変更するために呼ばれます。\nデフォルトでは受け取った結果をそのまま返します。  注意点  MonoBehaviourのenabledは実行制御のために内部で使用しているため、代替となるbehaviourEnabledを使用してください。  呼び出し順 \r  ノードに複数のDecoratorを追加している場合は上から順に呼ばれます。 OnEnableとOnDisable以外のMonoBehaviourのコールバックメソッドも使用できますが、Start()はOnConditionCheck()などの後に呼ばれてしまうため注意してください。  変数の宣言 \r 作成したスクリプトにpublicもしくはSerializedField属性をつけたフィールドを宣言することでArbor Editorで編集可能になります。\n1 2 3 4 5 6 7 8 9 10 11  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; using Arbor.BehaviourTree; [AddComponentMenu(\u0026#34;\u0026#34;)] public class TestDecorator : Decorator { public string myName; // 略 }    データフロー Decoratorではデータフローによる値の入出力が可能です。\n詳しくは、「スクリプティング : データフロー」を参照してください。\nスクリプティング : データフロー\n"
    },
    {
        "uri": "/manual/scripting/behaviourtree.html",
        "title": "BehaviourTree",
        "tags": [],
        "description": "",
        "summary": "BehaviourTreeでもスクリプトを記述することでカスタマイズできます。 ActionBehaviour アクションノードに割り当てるスクリプトについて説明します。 Decorator",
        "content": "BehaviourTreeでもスクリプトを記述することでカスタマイズできます。\n ActionBehaviour\nアクションノードに割り当てるスクリプトについて説明します。 Decorator\nデコレータスクリプトについて説明します。 Service\nサービススクリプトについて説明します。  "
    },
    {
        "uri": "/manual/behaviourtree/howtouse/opengraph.html",
        "title": "BehaviourTreeグラフを開く",
        "tags": [],
        "description": "",
        "summary": "BehaviourTreeを編集するにはArbor EditorウィンドウでBehaviourTreeグラフを開く必要があります。 Hierar",
        "content": "BehaviourTreeを編集するにはArbor EditorウィンドウでBehaviourTreeグラフを開く必要があります。\n HierarchyウィンドウでBehaviourTreeコンポーネントが付いたGameObjectを選択。 InspectorウィンドウのBehaviourTreeコンポーネントエディタの\u0026quot;Open Editor\u0026quot;ボタンをクリック。  \r また、すでにArbor Editorウィンドウが開いている場合はHierarchyウィンドウでBehaviourTreeコンポーネントが付いたGameObjetを選択すると切り替わります。\n"
    },
    {
        "uri": "/manual/scripting/parameterreference/flexiblefield.html",
        "title": "FlexibleField",
        "tags": [],
        "description": "",
        "summary": "FlexibleField関連クラスを使用すると、固定値の指定やパラメータ参照もしくはデータフローからの入力を切り替えて参照できます。 スクリ",
        "content": "FlexibleField関連クラスを使用すると、固定値の指定やパラメータ参照もしくはデータフローからの入力を切り替えて参照できます。\nスクリプト例 1 2 3 4 5 6 7 8 9 10 11 12 13  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestFlexibleFieldBehaviour : StateBehaviour\r{\rpublic FlexibleInt flexibleInt;\rpublic override void OnStateBegin()\r{\rDebug.Log(\u0026#34;flexibleInt : \u0026#34; + flexibleInt.value);\r}\r}    このスクリプトをArborFSMのステートに追加すると以下のようになります。\n\r フィールド右端にあるボタンをクリックすると参照方法が変更できます。\n\r 「Parameter」に変更することで、ParameterReferenceと同じように参照できるようになります。\n\r FlexibleField関連クラス  FlexibleInt FlexibleFloat FlexibleBool FlexibleGameObject FlexibleString FlexibleEnumAny FlexibleVector2 FlexibleVector3 FlexibleQuaternion FlexibleRect FlexibleBounds FlexibleColor FlexibleTransform FlexibleRectTransform FlexibleRigidbody FlexibleRigidbody2D FlexibleComponent FlexibleLong FlexibleField\n(Variableパラメータの参照に使用します)  "
    },
    {
        "uri": "/manual/scripting/dataflow/inputslot.html",
        "title": "入力スロット",
        "tags": [],
        "description": "",
        "summary": "InputSlotIntなどの入力スロットを宣言することでデータ出力ができます。 スクリプト例 TestInputSlotBehaviourスク",
        "content": "InputSlotIntなどの入力スロットを宣言することでデータ出力ができます。\nスクリプト例 TestInputSlotBehaviourスクリプトファイルを作成し、以下のコードを記述してください。\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestInputSlotBehaviour : StateBehaviour\r{\rpublic InputSlotInt inputSlot;\rpublic override void OnStateBegin()\r{\rint intValue = 0;\rif (inputSlot.GetValue(ref intValue))\r{\rDebug.Log(\u0026#34;inputSlot : \u0026#34; + intValue);\r}\relse\r{\rDebug.LogWarning(\u0026#34;inputSlot : not connected.\u0026#34;);\r}\r}\r}    このスクリプトをArborFSMのステートに追加すると以下のようになります。\n\r 入力スロットクラス  InputSlotInt InputSlotFloat InputSlotBool InputSlotGameObject InputSlotString InputSlotVector2 InputSlotVector3 InputSlotQuaternion InputSlotRect InputSlotBounds InputSlotColor InputSlotTransform InputSlotRectTransform InputSlotRigidbody InputSlotRigidbody2D InputSlotComponent InputSlotLong InputSlotCollider InputSlotCollider2D InputSlotCollision InputSlotCollision2D InputSlotRaycastHit InputSlotRaycastHit2D InputSlotUnityObject InputSlotAny  "
    },
    {
        "uri": "/manual/window/typeselect.html",
        "title": "型選択ウィンドウ",
        "tags": [],
        "description": "",
        "summary": "型を選択するウィンドウ UI説明 検索バー 型名で検索できます。 フィルター 型の種類によるフィルターを切り替えます。 フィルターリスト フィルタリングす",
        "content": "\r型を選択するウィンドウ\n\r UI説明 検索バー \r 型名で検索できます。\nフィルター \r 型の種類によるフィルターを切り替えます。\nフィルターリスト \r フィルタリングする型の種類のリストです。\n型リスト \r 選択可能な型のリストです。\nクリックで型を選択できます。\n"
    },
    {
        "uri": "/manual/subgraph/argument.html",
        "title": "グラフの引数",
        "tags": [],
        "description": "",
        "summary": "親グラフと子グラフとの間でパラメータの受け渡しが可能です。 受け渡すパラメータの作成 子グラフをArborEditorで開く。 サイドパネルのパラ",
        "content": "\r 親グラフと子グラフとの間でパラメータの受け渡しが可能です。\n受け渡すパラメータの作成  子グラフをArborEditorで開く。 サイドパネルのパラメータタブを開く。 親グラフとの受け渡しを行うパラメータを作成。 必要に応じて、GetとSetの可視設定を変更する。  \r 子グラフでパラメータの受け取り  受け取るパラメータをグラフビューにドラッグ＆ドロップ。 メニューからGetを選択。 GetParameterの出力スロットから値を出力し、他ノードで値を使用。  \r 子グラフでパラメータの設定  設定するパラメータをグラフビューにドラッグ＆ドロップ。 メニューからSetを選択。 入力スロットに設定値を接続。  \r 親グラフからパラメータを受け渡し  親グラフをArborEditorで開く。 サブグラフの引数リストに受け渡したいパラメータを追加する。 固定値や入力スロットから値を設定。  \r 子グラフからのパラメータを受け取り  サブグラフの引数リストに受け取りたいパラメータを追加する。 出力スロットから値を出力し、他ノードで値を使用。  \r 引数の更新タイミング パラメータを更新するタイミングを指定できます。\n 更新タイミングフィールドをクリック。 タイミングを選択。  \r 更新タイミング    項目 説明     Enter ノードがアクティブになり、子グラフが再生開始される際に更新   Execute 毎フレーム、子グラフが実行される際に更新    引数の設定 引数にはGetやSetの可視設定が行えます。\nSetを行わずパラメータの値を上書きしたくない場合などに使用して下さい。\n 引数の歯車アイコンをクリック 設定ウィンドウにて引数の設定。  \r 引数設定ウィンドウ \r    項目 説明     Set 入力フィールドの可視設定   Get 出力フィールドの可視設定    実行される子グラフが確定していない場合 SubStateMachineReferenceなどで実行される子グラフが確定していない場合は、受け渡すパラメータ名やタイプなどを指定する必要があります。\n 引数リストの+ボタンをクリック。 引数作成ウィンドウにてパラメータ名やタイプなどを記入し作成。  \r 引数ウィンドウ \r引数作成ウィンドウ\n\r \r引数設定ウィンドウ\n\r    項目 説明     Parameter Name 受け渡したいパラメータの名前。子グラフのパラメータと同名でなければならない。   Parameter Type 受け渡したいパラメータのタイプ。\n子グラフのパラメータと同じタイプでなければならない。   Reference Type\n(Parameter TypeがEnum、Component、Variableのみ) 受け渡したいパラメータの型\n子グラフのパラメータと同じ型でなければならない。   Set 入力フィールドの可視設定   Get 出力フィールドの可視設定    "
    },
    {
        "uri": "/manual/getting-started/preparation.html",
        "title": "Arborを使用するための準備",
        "tags": [],
        "description": "",
        "summary": "Arborを入手する アセットストアから購入してください。 プロジェクト作成 Arborを使用するプロジェクトがまだない場合は新規に作成する必要が",
        "content": "Arborを入手する アセットストアから購入してください。\n\rプロジェクト作成 Arborを使用するプロジェクトがまだない場合は新規に作成する必要があります。\n\r プロジェクトの作成方法についての詳細はUnity ManualのGetting startedを参照してください。\n最後に「作成」ボタンを押してプロジェクトを作成します。\nArborのインポート Arborをインポートするために、まずAssetStoreウィンドウを表示します。\nメニューから、「Window \u0026gt; Asset Store」を選択するか、ショートカットのCtrl + 9を押してください。\n\r AssetStoreウィンドウが表示されたらツールバーの「My Assets」ボタンをクリックしダウンロード一覧に切り替えます。\nリストからArbor 3パッケージを見つけてください。\n\r 「ダウンロード」ボタンが表示されている場合はクリックしてダウンロードを開始します。\n「インポート」ボタンをクリックするとImport Unity Packageウィンドウが表示されます。\n\r ウィンドウ右下のImportボタンをクリックすることでインポート完了です。\n"
    },
    {
        "uri": "/manual/scripting/behaviourattribute/behaviourtitle.html",
        "title": "BehaviourTitle",
        "tags": [],
        "description": "",
        "summary": "挙動のタイトルバーに表示される名前を変更します。 スクリプトリファレンス : BehaviourTitle 使用例 スクリプト TestBehaviourTitleという名前でス",
        "content": "挙動のタイトルバーに表示される名前を変更します。\nスクリプトリファレンス : BehaviourTitle\n使用例 スクリプト TestBehaviourTitleという名前でスクリプトを作成し、以下のコードを記入してください。\n1 2 3 4 5 6 7 8 9 10  using UnityEngine;\rusing System.Collections;\rusing System.Collections.Generic;\rusing Arbor;\r[BehaviourTitle(\u0026#34;Manual Example\u0026#34;)]\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestBehaviourTitle : StateBehaviour\r{\r}    動作確認 ステートの「挙動追加」から「Scripts / TestBehaviourTitle」を選択し、挙動のタイトルバーを確認します。\n\r "
    },
    {
        "uri": "/manual/dataflow/calculator.html",
        "title": "演算ノード",
        "tags": [],
        "description": "",
        "summary": "演算ノードはデータの入出力を持った演算用ノードです。 数値計算を行ったりフィールドにアクセスして出力したりできます。 演算ノードの作成 Arbor Edit",
        "content": "演算ノードはデータの入出力を持った演算用ノードです。\n数値計算を行ったりフィールドにアクセスして出力したりできます。\n演算ノードの作成  Arbor Editorの適当な位置を右クリック。 「演算ノード作成」をクリック。\n作成したい演算ノードをリストから選択  \r 組み込みCalculator よく使用する演算ノードは初めから用意されています。\nArborリファレンス : Calculator リファレンス\n"
    },
    {
        "uri": "/manual/parametercontainer/parameters.html",
        "title": "パラメータの種類",
        "tags": [],
        "description": "",
        "summary": "種類 Inspector 説明 Int 符号付き32bit整数 Long 符号付き64bit整数 Float 符号付き32bit浮動小数点数 Bool ブーリアン String 文字列 Enum enum型(型指定可能) Vector2 ２",
        "content": "\r    種類 Inspector 説明     Int \r  符号付き32bit整数   Long \r  符号付き64bit整数   Float \r  符号付き32bit浮動小数点数   Bool \r  ブーリアン   String \r  文字列   Enum \r  enum型(型指定可能)   Vector2 \r  ２次元ベクトル   Vector3 \r  ３次元ベクトル   Quaternion \r  ４元数   Rect \r  2次元の矩形   Bounds \r  ３次元空間の範囲   Color \r  色   GameObject \r  GameObjectの参照   Transform \r  Transformコンポーネントの参照   RectTransform \r  RectTransformコンポーネントの参照   Rigidbody \r  Rigidbodyコンポーネントの参照   Rigidbody2D \r  Rigidbody2Dコンポーネントの参照   Component \r  コンポーネントの参照(型指定可能)   AssetObject \r  アセットオブジェクトの参照(型指定可能)   Variable  自作可能なパラメータ型   IntList \r  符号付き32bit整数のリスト   LongList \r  符号付き64bit整数のリスト   FloatList \r  符号付き32bit浮動小数点数のリスト   BoolList \r  ブーリアンのリスト   StringList \r  文字列のリスト   EnumList \r  enum型(型指定可能)のリスト   Vector2List \r  ２次元ベクトルのリスト   Vector3List \r  3次元ベクトルのリスト   QuaternionList \r  ４元数のリスト   RectList \r  2次元の矩形のリスト   BoundsList \r  ３次元空間の範囲のリスト   ColorList \r  色のリスト   GameObjectList \r  GameObjectの参照のリスト   ComponentList \r  コンポーネントの参照(型指定可能)のリスト   AssetObjectList \r  アセットオブジェクトの参照(型指定可能)のリスト   VariableList  自作可能なパラメータ型のリスト    Variableについて Variableを使用するとパラメータを自作することができます。\n詳しくは、「スクリプティング : Variable」を参照してください。\nスクリプティング : Variable\n"
    },
    {
        "uri": "/manual/statemachine/howtouse/state.html",
        "title": "ステート",
        "tags": [],
        "description": "",
        "summary": "ステートの編集方法について説明します。 ステートの作成 ノードを作成したいグラフの位置を右クリック メニューの”ステート作成”を選択 ステートの名前",
        "content": "ステートの編集方法について説明します。\nステートの作成  ノードを作成したいグラフの位置を右クリック メニューの”ステート作成”を選択 ステートの名前を入力し、Enterキーで決定。  \r 常駐ステートの作成  ノードを作成したいグラフの位置を右クリック メニューの”常駐ステート作成”を選択 ステートの名前を入力し、Enterキーで決定。  \r ステートの削除  削除したいノードを選択 グラフ内の右クリックメニューから”削除”を選択、もしくはDeleteキーを押す  \r 開始ステートに設定  ノードヘッダ部の歯車アイコンをクリックするかヘッダ部を右クリック 「開始ステートに設定」を選択。  \r 挙動追加 ステートを動作させるためには、StateBehaviourを追加する必要があります。\n ノードヘッダ部の歯車アイコンをクリックするかヘッダ部を右クリック “挙動追加”を選択 StateBehaviour選択メニューから追加したいStateBehaviourを選択。  \r 選択メニューの詳細は挙動選択ウィンドウを参照してください。\n挙動挿入 StateBehaviourを任意の位置に挿入するには、「挙動挿入」ボタンから追加します。\n ステートの挙動間のセパレータの中央付近をマウスオーバーする。 表示された「挙動挿入」ボタンをクリック。 「挙動追加」を選択 StateBehaviour選択メニューから追加したいStateBehaviourを選択。  \r 挙動のドラッグ 移動 StateBehaviourをドラッグ＆ドロップすることで、挙動の順番の入れ替えや他ノードへの移動ができます。\n 挙動のタイトルバーをドラッグ 同じノードの他の位置や他のノードへドロップ  \r コピー Ctrl(Win) / option (Mac)を押しながらドラッグ＆ドロップするとコピーになります。\n 挙動のタイトルバーをドラッグ Ctrl(Win) / option (Mac)を押しながら、同じノードの他の位置や他のノードへドロップ  \r 挙動の削除  StateBehaviourのタイトルバーの歯車アイコンをクリックするかタイトルバー部を右クリック メニューの”削除”を選択  \r 挙動のプリセット Unityのプリセット機能が使用できます。\n(Unity 2018.1以降対応)\nプリセットの保存  StateBehaviourのタイトルバーのプリセットアイコンをクリック Select Presetウィンドウで\u0026quot;Save current to\u0026hellip;\u0026ldquo;ボタンをクリック 名前を付けて保存  \r プリセットを適用  StateBehaviourのタイトルバーのプリセットアイコンをクリック Select Presetウィンドウで適用したいプリセットを選択  \r ステートの接続 既存ノードへの接続  StateBehaviourのStateLinkフィールドをドラッグ 接続先のステートにドロップ  \r 接続先をノードリストで選択  StateBehaviourのStateLinkフィールドをドラッグ グラフの何もないところでドロップ メニューの\u0026quot;ノードリスト選択\u0026quot;を選択 ノードリストで接続先のステートを選択  \r ステートを新規作成して接続  StateBehaviourのStateLinkフィールドをドラッグ ステートを作成したいグラフ内の位置でドロップ メニューの”ステート作成”を選択 ステートの名前を入力し、Enterキーで決定。  \r ステートの接続を切断  接続を切断したい接続ライン上を右クリック メニューの”切断”を選択  \r StateLinkの設定 StateLinkの歯車アイコンをクリックすると設定ウィンドウが表示されます。\n\r    項目 内容     Name StateLinkの名前。 入力するとStateLinkフィールドの表示名が変更される。   Transition Timing 遷移タイミングの設定。   Line Color 接続ラインの色    TransitionTiming    項目 内容     Late Update Overwrite LateUpdate時に遷移するよう予約する。\n同フレーム内で既に遷移予約されている場合は上書きする。   Immediate 遷移呼び出し時に瞬時に遷移する。\n遷移がループしている場合、無限ループする可能性もあるので使用には注意すること。   Late Update Dont Overwrite LateUpdate時に遷移するよう予約する。(デフォルト)\n同フレーム内で既に遷移予約されている場合は上書きしない。    スクリプティング スクリプトによるカスタマイズについてはこちらを参照してください\nスクリプティング : StateBehaviour\n"
    },
    {
        "uri": "/manual/statemachine/howtouse.html",
        "title": "ステートマシンの使い方",
        "tags": [],
        "description": "",
        "summary": "ここでは、ステートマシンの詳しい使い方について説明します。 ArborFSMコンポーネントの追加 GameObjectにArborFSMコンポー",
        "content": "ここでは、ステートマシンの詳しい使い方について説明します。\n ArborFSMコンポーネントの追加\nGameObjectにArborFSMコンポーネントを追加する方法について説明します。 ArborFSMグラフを開く\nArborFSMグラフを編集するためにArbor Editorウィンドウで開く方法について説明します。 ステート\nArborFSMグラフのステートを編集する方法について説明します。 リルートノード\nArborFSMグラフのリルートノードを編集する方法について説明します。  "
    },
    {
        "uri": "/manual/statemachine.html",
        "title": "ステートマシン",
        "tags": [],
        "description": "",
        "summary": "ここでは、ステートマシンの概要についての説明や使用方法について説明します。 ステートマシンとは？ ステートマシンの概要について説明します。 ノード",
        "content": "\r ここでは、ステートマシンの概要についての説明や使用方法について説明します。\n ステートマシンとは？\nステートマシンの概要について説明します。 ノードの構成要素\nステートマシンで使用するノードについて説明します。 ステートマシンの使い方\n詳しい使用方法について説明します。 各メニューについて\n各種メニューについて説明します。  "
    },
    {
        "uri": "/manual/arboreditor/nodes.html",
        "title": "グラフ共通のノード",
        "tags": [],
        "description": "",
        "summary": "全てのグラフで使用できる共通のノードについて説明します。 コメントノード コメントを設定できるノードです。 グループノード ノードを一つのグループに",
        "content": "全てのグラフで使用できる共通のノードについて説明します。\n コメントノード\nコメントを設定できるノードです。 グループノード\nノードを一つのグループにまとめるためのノードです。 演算ノード\nデータフローで使用する演算用のノードです。  "
    },
    {
        "uri": "/manual/arboreditor/howtouse.html",
        "title": "グラフ共通の使い方",
        "tags": [],
        "description": "",
        "summary": "基本的な操作方法 操作 Windows Mac スクロール マウス中ボタンドラッグ マウス中ボタンドラッグ Alt + マウス左ボタンドラッグ option ⌥ + マウスボタンドラッグ スクロール",
        "content": "基本的な操作方法    操作 Windows Mac     スクロール マウス中ボタンドラッグ マウス中ボタンドラッグ    Alt + マウス左ボタンドラッグ option ⌥ + マウスボタンドラッグ    スクロールバーでの操作 スクロールバーでの操作    ホイールスクロール\n(設定でズームと切り替え) ホイールスクロール\n(設定でズームと切り替え)   ズームアウト\n(Unity2017.3.0以降のみ) ホイールスクロール\n(設定でスクロールと切り替え) ホイールスクロール\n(設定でスクロールと切り替え)    Alt + マウス右ボタンドラッグ option ⌥ + control ⌃ + マウスボタンドラッグ   ノードの矩形選択 マウス左ボタンドラッグ マウスボタンドラッグ   ノードの移動 ノード上でマウス左ボタンドラッグ ノード上でマウスボタンドラッグ   ノードのリサイズ ノードのエッジをマウス左ボタンドラッグ ノードのエッジをマウスボタンドラッグ   コンテキストメニュー マウス右クリック control ⌃ + マウスクリック    ノードの作成方法などについては各グラフのマニュアルを参照してください。\nショートカットキー    操作 Windows Mac     ノードのコピー Ctrl + Cキー command ⌘ + Cキー   ノードの切り取り Ctrl + Xキー command ⌘ + Xキー   ノードの貼り付け Ctrl + Vキー command ⌘ + Vキー   ノードの複製 Ctrl + Dキー command ⌘ + Dキー   ノードの削除 Deleteキー Deleteキー   選択中ノードの位置にスクロール Fキー Fキー   ノードの全選択 Ctrl + Aキー command ⌘ + Aキー    ノードの名前変更  ノード枠内上部にあるヘッダ部分をダブルクリック、あるいは右クリックか設定アイコンから「リネーム」を選択。\n表示されたテキストボックスに入力。  \r ノードの削除  削除したいノードを選択。 何もない箇所を右クリックし「削除」を選択、もしくはDeleteキーを押す。\n\r   マニュアルを開く 組み込みスクリプトやBehaviourHelp属性をつけたスクリプトは、マニュアルを開くヘルプアイコンが表示されます。\n 各種挙動のタイトルバー横にあるヘルプアイコンをクリックする\n\r   スクリプティング : BehaviourHelp\n"
    },
    {
        "uri": "/manual/arboreditor/nodes/calculator.html",
        "title": "演算ノード",
        "tags": [],
        "description": "",
        "summary": "データフローで使用可能な演算用ノードです。 詳しい使用方法は、データフローを参照してください。",
        "content": "\r データフローで使用可能な演算用ノードです。\n詳しい使用方法は、データフローを参照してください。\n"
    },
    {
        "uri": "/manual/scripting/behaviourtree/service.html",
        "title": "Service",
        "tags": [],
        "description": "",
        "summary": "Serviceのスクリプトを作成し、行いたい処理を記述することで独自の更新処理などを追加できます。 Serviceスクリプトファイルの作成 Pr",
        "content": "Serviceのスクリプトを作成し、行いたい処理を記述することで独自の更新処理などを追加できます。\nServiceスクリプトファイルの作成  Projectウィンドウから作成したい場所で右クリック。 右クリックメニューから、「Create \u0026gt; Arbor \u0026gt; BehaviourTree \u0026gt; Service C# Script」を選択。\n\r  ファイル名を入力して決定  呼び出される関数 作成したServiceをコンポジットノードやアクションノードに追加すると、スクリプトの各関数が呼びだされるようになります。\n OnAwake\n初めてノードがアクティブになった時に呼ばれます。 OnStart\nノードがアクティブになった時に呼ばれます。 OnUpdate\nノードがアクティブの間、毎回呼ばれます。\n実行タイミングについては、BehaviourTreeのUpdateSettingsを参照してください。\nArborリファレンス : BehaviourTree OnAbort\nノードがDecoratorにより中断する時に呼ばれます。 OnEnd\nノードが終了するときに呼ばれます。  注意点  MonoBehaviourのenabledは実行制御のために内部で使用しているため、代替となるbehaviourEnabledを使用してください。  呼び出し順 \r  ノードに複数のServiceを追加している場合は上から順に呼ばれます。 OnEnableとOnDisable以外のMonoBehaviourのコールバックメソッドも使用できますが、Start()は初回OnUpdate()の後に呼ばれてしまうため注意してください。  変数の宣言 \r 作成したスクリプトにpublicもしくはSerializedField属性をつけたフィールドを宣言することでArbor Editorで編集可能になります。\n1 2 3 4 5 6 7 8 9 10 11 12  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; using Arbor.BehaviourTree; [AddComponentMenu(\u0026#34;\u0026#34;)] public class TestService : Service { public string myName; // 略 }    データフロー Serviceではデータフローによる値の入出力が可能です。\n詳しくは、「スクリプティング : データフロー」を参照してください。\nスクリプティング : データフロー\n"
    },
    {
        "uri": "/manual/behaviourtree/howtouse/nodes.html",
        "title": "ノード",
        "tags": [],
        "description": "",
        "summary": "コンポジットノードの作成 ノードを作成したいグラフの位置を右クリック メニューの\u0026quot;コンポジット作成\u0026quot;を選択 コンポジット選択ウ",
        "content": "コンポジットノードの作成  ノードを作成したいグラフの位置を右クリック メニューの\u0026quot;コンポジット作成\u0026quot;を選択 コンポジット選択ウィンドウで作成したいコンポジットを選択。  \r アクションノードの作成  ノードを作成したいグラフの位置を右クリック メニューの\u0026quot;アクション作成\u0026quot;を選択 アクション選択ウィンドウで作成したいアクションを選択。  \r アクションスクリプトの作成についてはこちら\nスクリプティング : ActionBehaviour\nノードの接続 ルートノードやコンポジットノード、アクションノードは親子関係を接続できます。\n既存ノードへの接続  ノードの上部または下部にある接続スロットをドラッグ 接続先のスロットへドロップ  \r ノードの新規作成して接続  ノードの上部または下部にある接続スロットをドラッグ ノードを作成したいグラフ内の位置でドロップ メニューの\u0026quot;コンポジット作成\u0026quot;か\u0026quot;アクション作成\u0026quot;を選択 各種スクリプト選択メニューで作成したいスクリプトを選択  \r ノードの接続を切断  接続を切断したい接続ライン上か接続スロットを右クリック メニューの\u0026quot;切断\u0026quot;を選択  \r ノードの優先順位変更 同じ親を持つ兄弟同士のノードはノードの位置関係によって優先順位が決まります。\n 優先順位を下げたい場合は、ノードをドラッグして 右に移動 。 優先順位を上げたい場合は、ノードをドラッグして 左に移動 。  \r ノードの削除  削除したいノードを選択 グラフ内の右クリックメニューから\u0026quot;削除\u0026quot;を選択、もしくはDeleteキーを押す  \r 子ノードをまとめて移動  ノードをAlt+ドラッグ（Macではoption ⌥ + ドラッグ）  \r コンポジット置き換え ノードの位置や接続状態などはそのままに、後からコンポジットだけ置き換えられます。\n ノードヘッダ部の歯車アイコンをクリックするかヘッダ部を右クリック 「コンポジット置き換え」を選択 コンポジット選択メニューからコンポジットを選択。  \r アクション置き換え ノードの位置や接続状態などはそのままに、後からアクションだけ置き換えられます。\n ノードヘッダ部の歯車アイコンをクリックするかヘッダ部を右クリック 「アクション置き換え」を選択 アクション選択メニューからアクションを選択。  \r デコレータ デコレータ追加 コンポジットノードかアクションノードにはデコレータが追加できます。\n ノードヘッダ部の歯車アイコンをクリックするかヘッダ部を右クリック 「デコレータ追加」を選択 デコレータ選択メニューから追加したいデコレータを選択。  \r デコレータスクリプトの作成についてはこちら\nスクリプティング : Decorator\nデコレータ挿入 任意の位置にデコレータを挿入できます。\n ノードヘッダ部とメイン挙動の間、中央付近をマウスオーバー。\nまたは、挿入したい位置のデコレータ間のセパレータの中央付近をマウス―オーバー。 「デコレータ挿入」ボタンをクリック 「デコレータ追加」を選択 デコレータ選択メニューから追加したいデコレータを選択。  \r デコレータ削除  デコレータのタイトルバーの歯車アイコンをクリックするかタイトルバー部を右クリック メニューの\u0026quot;削除\u0026quot;を選択  \r サービス サービス追加 コンポジットノードかアクションノードにはサービスが追加できます。\n ノードヘッダ部の歯車アイコンをクリックするかヘッダ部を右クリック 「サービス追加」を選択 サービス選択メニューから追加したいサービスを選択。  \r なお、サービスには組み込みスクリプトがないため予めサービススクリプトを作成しておく必要があります。\nサービススクリプトの作成についてはこちら\nスクリプティング : Service\nサービス挿入 任意の位置にサービスを挿入できます。\n メイン挙動とノード下部の間の中央付近をマウスオーバー。\nまたは、挿入したい位置のサービス間のセパレータの中央付近をマウス―オーバー。 「サービス挿入」ボタンをクリック 「サービス追加」を選択 サービス選択メニューから追加したいサービスを選択。  \r サービス削除  サービスのタイトルバーの歯車アイコンをクリックするかタイトルバー部を右クリック メニューの\u0026quot;削除\u0026quot;を選択  \r スクリプティング 各種スクリプトによるカスタマイズについてはこちらを参照してください\nスクリプティング\n"
    },
    {
        "uri": "/manual/behaviourtree/howtouse.html",
        "title": "ビヘイビアツリーの使い方",
        "tags": [],
        "description": "",
        "summary": "ここでは、ビヘイビアツリーの詳しい使い方について説明します。 BehaviourTreeコンポーネントの追加 GameObjectにBehavi",
        "content": "ここでは、ビヘイビアツリーの詳しい使い方について説明します。\n BehaviourTreeコンポーネントの追加\nGameObjectにBehaviourTreeコンポーネントを追加する方法について説明します。 BehaviourTreeグラフを開く\nBehaviourTreeを編集するためにArbor Editorウィンドウで開く方法について説明します。 ノード\nBehaviourTreeグラフのノードを編集する方法について説明します。  "
    },
    {
        "uri": "/manual/scripting/dataflow/flexiblefield.html",
        "title": "FlexibleField",
        "tags": [],
        "description": "",
        "summary": "入力スロットだけでなく、固定値やパラメータも扱いたい場合はFlexibleFieldが便利です。 スクリプト例 TestFlexibleFiel",
        "content": "入力スロットだけでなく、固定値やパラメータも扱いたい場合はFlexibleFieldが便利です。\nスクリプト例 TestFlexibleFieldBehaviourスクリプトファイルを作成し、以下のコードを記述してください。\n1 2 3 4 5 6 7 8 9 10 11 12 13  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestFlexibleFieldBehaviour : StateBehaviour\r{\rpublic FlexibleInt flexibleInt;\rpublic override void OnStateBegin()\r{\rDebug.Log(\u0026#34;flexibleInt : \u0026#34; + flexibleInt.value);\r}\r}    このスクリプトをArborFSMのステートに追加すると以下のようになります。\n\r FlexibleField関連クラス  FlexibleInt FlexibleFloat FlexibleBool FlexibleGameObject FlexibleString FlexibleEnumAny FlexibleVector2 FlexibleVector3 FlexibleQuaternion FlexibleRect FlexibleBounds FlexibleColor FlexibleTransform FlexibleRectTransform FlexibleRigidbody FlexibleRigidbody2D FlexibleComponent FlexibleLong FlexibleField\n(継承して使用します)  "
    },
    {
        "uri": "/manual/scripting/parameterreference/constraint.html",
        "title": "参照する型の制約",
        "tags": [],
        "description": "",
        "summary": "AnyParameterReferenceやComponentParameterReferenceなどは属性を指定することで、参照する型を制",
        "content": "AnyParameterReferenceやComponentParameterReferenceなどは属性を指定することで、参照する型を制約することができます。\nスクリプト例 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestConstraintReferenceBehaviour : StateBehaviour\r{\r[ClassExtends(typeof(AudioSource))]\rpublic ComponentParameterReference audioSource = new ComponentParameterReference();\r[ClassExtends(typeof(AudioClip))]\rpublic AssetObjectParameterReference audioClip = new AssetObjectParameterReference();\r// Use this for enter state\r\tpublic override void OnStateBegin()\r{\rAudioSource source = audioSource.value as AudioSource;\rif (source != null)\r{\rsource.clip = audioClip.value as AudioClip;\r}\r}\r}    スクリプトを追加した例\n\r ParameterContainer例\n\r 使用できる属性の例    対象の型 属性     ComponentParameterReference ClassTypeConstraintAttributeから派生したクラスSlotTypeAttribute指定の他、Componentクラスに制約される。   AssetObjectParameterReference ClassTypeConstraintAttributeから派生したクラスSlotTypeAttribute指定の他、アセットオブジェクト型に制約される。    "
    },
    {
        "uri": "/manual/scripting/calculator.html",
        "title": "演算ノード",
        "tags": [],
        "description": "",
        "summary": "演算ノードをカスタマイズするには、演算ノード用のスクリプトファイルを作成し、行いたい処理を記述する必要があります。 Calculatorスクリ",
        "content": "演算ノードをカスタマイズするには、演算ノード用のスクリプトファイルを作成し、行いたい処理を記述する必要があります。\nCalculatorスクリプトファイルの作成  Projectウィンドウから作成したい場所で右クリック。 右クリックメニューから、「Create \u0026gt; Arbor \u0026gt; Calculator C# Script」を選択。\n\r  ファイル名を入力して決定  呼び出される関数 作成したCalculatorをArborEditorにて演算ノードに割り当てると、スクリプトの各関数が呼び出されるようになります。\n OnCalculate\n演算が必要な際に呼ばれます。\nここで演算処理を記述し、OutputSlot.SetValueにてデータを出力してください。 OnCheckDirty\n再演算が必要かどうかの判定に呼ばれます。必要に応じてoverrideしてください。\n演算に必要なデータが変更されており再演算が必要かどうかを返してください。\n入力スロットの接続状態による再演算はArborの内部的に判定しているため意識する必要はありません。\n(Transform.positionなど、外部オブジェクトの値を取り扱う際にtrueを返すようにする必要があります) MonoBehaviourのメッセージ関数\n詳しくはUnity ScriptReferenceのMonoBehaviourのMessagesを参照してください。  演算の流れ  必要に応じてInputSlot.GetValue()を呼び出します。 再演算が必要かどうかの判定にOnCheckDirtyが呼ばれます。\n(ステートなどからOutputSlot.SetValueによって事前に値が変更されていた場合はOnCheckDirtyの結果にかかわらず再演算が行われます) 再演算が必要な場合にOnCalculateが呼ばれます。  OnCaluculateの中で必要に応じてInputSlot.GetValue()を呼び出します。 以下、再演算が必要なくなるまでInputSlotを辿って値を取得します。    変数とArbor Editor 基本はStateBehaviourの変数とArbor Editorと同じく、変数を宣言することでArbor Editorに表示され編集可能になります。\nデータフロー 演算ノードを活用するには、データフローによる値の入出力が重要です。\n詳しくは、「スクリプティング : データフロー」を参照してください。\nスクリプティング : データフロー]\n"
    },
    {
        "uri": "/manual/window/memberselect.html",
        "title": "メンバー選択ウィンドウ",
        "tags": [],
        "description": "",
        "summary": "メンバーを選択するウィンドウ UI説明 検索バー メンバー名で検索できます。 フィルター メンバーの種類によるフィルターを切り替えます。 フィルターリス",
        "content": "\rメンバーを選択するウィンドウ\n\r UI説明 検索バー \r メンバー名で検索できます。\nフィルター \r メンバーの種類によるフィルターを切り替えます。\nフィルターリスト \r フィルタリングするメンバーの種類のリストです。\nメンバーリスト \r 選択可能なメンバーのリストです。\nクリックでメンバーを選択できます。\n"
    },
    {
        "uri": "/manual/scripting/behaviourattribute/behaviourhelp.html",
        "title": "BehaviourHelp",
        "tags": [],
        "description": "",
        "summary": "挙動のタイトルバーに表示されるヘルプボタンをクリックすると開かれるURLを指定する属性です。 スクリプトリファレンス : BehaviourHelp 使用例 スクリプト Tes",
        "content": "挙動のタイトルバーに表示されるヘルプボタンをクリックすると開かれるURLを指定する属性です。\nスクリプトリファレンス : BehaviourHelp\n使用例 スクリプト TestBehaviourHelpという名前でスクリプトを作成し、以下のコードを記入してください。\n1 2 3 4 5 6 7 8 9 10  using UnityEngine;\rusing System.Collections;\rusing System.Collections.Generic;\rusing Arbor;\r[BehaviourHelp(\u0026#34;https://assetstore.unity.com/packages/slug/112239\u0026#34;)]\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestBehaviourHelp : StateBehaviour\r{\r}    動作確認 ステートの「挙動追加」から「Scripts / TestBehaviourHelp」を選択し、挙動のタイトルバーに表示されているヘルプボタンをクリックしてください。\n\r "
    },
    {
        "uri": "/manual/dataflow/list.html",
        "title": "リスト(配列)",
        "tags": [],
        "description": "",
        "summary": "Arborのデータフローはリスト(配列)に対応しております。 アクセスには各演算ノードやステートの挙動を利用してください。 リストを使った例 Pa",
        "content": "Arborのデータフローはリスト(配列)に対応しております。\nアクセスには各演算ノードやステートの挙動を利用してください。\nリストを使った例 \r ParameterContainerに設定したリストからランダムで要素を取り出す例を紹介します。\nGetParameter  グラフのパラメータにStringListパラメータを追加。\n\r  GetParameterで取得します。\n\r   List.Count  List.Count演算ノードを追加し、string型リストの要素数を取得します。\n\r   Random.RangeInt  取得したリストの要素数を使用してランダムなインデックスを求めます。\n\r   List.GetElement  ランダムなインデックスからリストの要素を取得します。\n\r   SetParameter  グラフのパラメータにSelectStringパラメータを追加。\n\r  取得したランダムな要素をSelectStringパラメータに設定。\n\r  ランダムに変わることを確認するために、TimeTransitionで1秒間隔で繰り返します。  演算ノード Listの要素を変更しない各種データを取得するには演算ノードを使用します。\n List.Contains List.Count List.GetElement List.IndexOf List.LastIndexOf List.ToArrayList NewArrayList  ステートの挙動 Listの要素を変更するにはステートの挙動を使用します。\n List.AddElement List.Clear List.InsertElement List.RemoveAtIndex List.RemoveElement List.SetElement  事前コンパイル(AOT)での制限 IL2CPPビルドなど事前コンパイル環境での制限により、コードから参照されていないList\u0026lt;T\u0026gt;を使用した場合に例外が発生します。\n事前コンパイルでの制限についての詳細は スクリプトの制限 - Unity マニュアル を参照してください。\nArborで問題が発生する使用方法は以下の通りです。\n Parameter  AssetObjectList ComponentList EnumList   List関連の組み込みスクリプト  このようなAOT問題を避けるには、以下のようなスクリプトを追加してください。\n1 2 3 4 5 6 7  using System.Collections.Generic;\rpublic class AOTCodeGeneration\r{\r// 例えばFoo型を作成してもList\u0026lt;Foo\u0026gt;はコードから使用していなかった場合。\r\tpublic List\u0026lt;Foo\u0026gt; myStructList = new List\u0026lt;Foo\u0026gt;();\r}    AOTCodeGenerationクラスを使用する必要はありません。\nこのようにスクリプトに記述することで、コンパイラーが適切なコードを生成するようになります。\n"
    },
    {
        "uri": "/manual/parametercontainer/access.html",
        "title": "パラメータへのアクセス",
        "tags": [],
        "description": "",
        "summary": "アクセスノードの作成 パラメータをグラフビューにドラッグ＆ドロップすることで、アクセスノードを作成できます。 パラメータのドラッグエリアをドラッ",
        "content": "アクセスノードの作成 パラメータをグラフビューにドラッグ＆ドロップすることで、アクセスノードを作成できます。\n パラメータのドラッグエリアをドラッグ グラフビューの作成したい位置でドロップ。 メニューから、GetかSetを選択。\n(Setノードの場合は、各種グラフの実行ノードが作成されます。作成したら実行されるように接続してください。)  \r ParameterReferenceによるアクセス ParameterReference関連クラスを持つスクリプトでは、値を扱うパラメータを設定できます。\nParameterReferenceフィールドによる設定  参照したいパラメータを持つParameterContainerを設定。 ドロップダウンからパラメータを設定。  \r データスロットから入力 Containerフィールドはデータスロットからの入力にも対応しています。\n あらかじめParameterContainer型のデータを出力するノードを作成しておく。 Containerフィールドのボタンをクリック。 DataSlotを選択。 データの入力スロットを接続。 Parameterフィールドには参照したいパラメータ名を文字列で設定。 (挙動によっては、Parameterのタイプも設定する必要があります)  \r データスロットについては、データフローを参照してください。\nパラメータをドラッグ\u0026amp;ドロップ  設定したいパラメータのドラッグエリアをドラッグ。 参照したいParameterReferenceへドロップ。  \r パラメータを参照するスクリプトの作成 自作のスクリプトからパラメータを参照できます。\n詳しくは、「スクリプティング : パラメータの参照」を参照してください。\nスクリプティング : パラメータの参照\n"
    },
    {
        "uri": "/manual/statemachine/howtouse/reroute.html",
        "title": "リルートノード",
        "tags": [],
        "description": "",
        "summary": "ステートの接続ラインを束ねたり方向を変更するにはリルートノードが使用できます。 接続 リルートノードを作成して接続 StateBehaviourの",
        "content": "ステートの接続ラインを束ねたり方向を変更するにはリルートノードが使用できます。\n接続 リルートノードを作成して接続  StateBehaviourのStateLinkフィールドをドラッグ リルートノードを作成したいグラフ内の位置でドロップ メニューの\u0026quot;リルート\u0026quot;を選択  \r 挿入  接続ライン上のリルートノードを作成したい位置を右クリック。 メニューの\u0026quot;リルート\u0026quot;を選択。  \r 方向変更  方向を変更するリルートノードを選択 表示される方向アイコンをドラッグして方向を変更。  \r 接続を保持したまま削除  リルートノードを右クリック 「削除(接続を保持)」を選択。  \r "
    },
    {
        "uri": "/manual/statemachine/menu.html",
        "title": "各メニューについて",
        "tags": [],
        "description": "",
        "summary": "グラフのメニュー グラフを右クリックするとメニューが表示されます。 項目 内容 ステート作成 通常ステートを作成します。 常駐ステート作成 常駐ステートを",
        "content": "グラフのメニュー グラフを右クリックするとメニューが表示されます。\n\r    項目 内容     ステート作成 通常ステートを作成します。   常駐ステート作成 常駐ステートを作成します。   演算ノード作成 演算ノードを作成します。   グループ作成 グループを作成します。   コメント作成 コメントを作成します。   切り取り 選択中のノードを切り取ります。   コピー 選択中のノードをコピーします。   貼り付け コピーしたノードを貼り付けます。   複製 選択中のノードを複製します。   削除 選択中のノードを削除します。   全て展開 選択中ノードの挙動を全て展開します。   全て折りたたみ 選択中ノードの挙動を全て折りたたみます。    ステートのメニュー ステートのヘッダ部を右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     リネーム ステートの名前を変更します。   コメント表示 ノードコメント欄の表示を切り替えます。   開始ステートに設定 開始ステートに設定します。   ブレークポイント ブレークポイントの設定を切り替えます。   挙動追加 StateBehaviourを追加します。   挙動を貼り付け コピーしたStateBehaviourを貼り付けます。   全て展開 ノードに追加されている全ての挙動を展開します。   全て折りたたみ ノードに追加されている全ての挙動を折りたたみます。   切り取り ノードを切り取ります。   コピー ノードをコピーします。   複製 ノードを複製します。   削除 ノードを削除します。   遷移（プレイ中のみ有効） プレイ中に選択することで、強制的に遷移します。    StateBehaviourのメニュー StateBehaviourのタイトルバーを右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     上に移動 挙動の順番を上に移動します。   下に移動 挙動の順番を下に移動します。   コピー StateBehaviourをコピーします。   貼り付け コピーしたStateBehaviourを上書きします（同じ型のみ有効）   削除 StateBehaviourを削除します。   スクリプト編集 スクリプトエディタを開きます。   Editorスクリプト編集 Editorスクリプトを開きます(Editorスクリプトがある時のみ)    接続ラインの右クリックメニュー 接続ライン上を右クリックすると、メニューが表示されます。\n\r    項目 内容     遷移元へ移動 遷移元のステートへスクロールします。   遷移先へ移動 遷移先のステートへスクロールします。   前のノードへ移動 前のノードへスクロールします（リルートノードがある場合のみ表示）   次のノードへ移動 次のノードへスクロールします（リルートノードがある場合のみ表示）   リルート クリックした位置にリルートノードを作成します。   切断 切断します。   設定 StateLinkの設定ウィンドウを開きます。    表示メニュー ツールバーの「表示」ボタンをクリックすると表示されます。\n\r    項目 内容     全て展開 折りたたまれている挙動を全て展開する   全て折りたたみ 展開されている挙動をすべて折りたたむ   ノードコメント \r 通常ノードごとの設定に従って表示する。全て表示全てのノードコメントを表示する。コメント済みのみ表示書き込まれているノードコメントのみを表示する。全て非表示全てのノードコメントを非表示にする。   データスロット \r ノード外に表示ノードの枠外にデータスロットを表示する。ノード内に表示ノードの枠内にデータスロットを表示する。フレキシブルに表示常に表示せず接続するときなどのみノードの枠外にデータスロットを表示する。   StateLink \r ノード上部に表示\r StateLinkをノードの上部に表示します。挙動上部に表示\r StateLinkを挙動の上部に表示します。挙動下部に表示\r StateLinkを挙動の下部に表示します。ノード下部に表示\r StateLinkをノードの下部に表示します。    デバッグメニュー ツールバーの「デバッグ」ボタンをクリックすると表示されます。\n\r    項目 内容     常にすべてのデータ値を表示 個々のデータラインの表示設定によらず常にデータ値を表示する   すべてのデータ値を表示 全てのデータラインの現在値を表示に変更します。   すべてのデータ値を非表示 全てのデータラインの現在値を非表示に変更します。   ブレークポイント設定 選択中ステートのブレークポイントを設定します。   ブレークポイント解除 選択中ステートのブレークポイントを解除します。   すべてのブレークポイントを解除 全てのステートのブレークポイントを解除します。   カウントクリア（プレイ中のみ有効） ステートの遷移回数を０に変更します。    リルートノードのメニュー \r    項目 内容     設定 StateLinkの設定ウィンドウを開きます。   切り取り ノードを切り取ります。   コピー ノードをコピーします。   複製 ノードを複製します。   削除 ノードを削除します。   削除（接続を保持） 接続を保持したままリルートノードのみ削除します。    "
    },
    {
        "uri": "/manual/behaviourtree/menu.html",
        "title": "各メニューについて",
        "tags": [],
        "description": "",
        "summary": "グラフのメニュー グラフを右クリックするとメニューが表示されます。 項目 内容 コンポジット作成 コンポジットノードを作成します。 アクション作成 アクシ",
        "content": "グラフのメニュー グラフを右クリックするとメニューが表示されます。\n\r    項目 内容     コンポジット作成 コンポジットノードを作成します。   アクション作成 アクションノードを作成します。   演算ノード作成 演算ノードを作成します。   グループ作成 グループを作成します。   コメント作成 コメントを作成します。   切り取り 選択中のノードを切り取ります。   コピー 選択中のノードをコピーします。   貼り付け コピーしたノードを貼り付けます。   複製 選択中のノードを複製します。   削除 選択中のノードを削除します。   全て展開 選択中ノードの挙動を全て展開します。   全て折りたたみ 選択中ノードの挙動を全て折りたたみます。    コンポジットノードのメニュー ノードのヘッダ部を右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     リネーム ノードの名前を変更します。   コメント表示 ノードコメント欄の表示を切り替えます。\r    ブレークポイント ブレークポイントの設定を切り替えます。\r    コンポジット置き換え 他のコンポジットスクリプトに置き換えます。   デコレータ追加 デコレータを追加します。   サービス追加 サービスを追加します。   デコレータを新規貼り付け コピーしたデコレータを貼り付けます。   サービスを新規貼り付け コピーしたサービスを貼り付けます。   全て展開 ノードの挙動をすべて展開します。   全て折りたたみ ノードの挙動をすべて折りたたみます。   切り取り ノードを切り取ります。   コピー ノードをコピーします。   複製 ノードを複製します。   削除 ノードを削除します。    コンポジットのメニュー タイトルバーを右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     コピー コンポジットをコピーします。   値を貼り付け コピーしたコンポジットの値で上書きします。（同じ型のみ有効）   スクリプト編集 スクリプトエディタを開きます。   Editorスクリプト編集 Editorスクリプトを開きます(Editorスクリプトがある時のみ)    アクションノードのメニュー ノードのヘッダ部を右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     リネーム ノードの名前を変更します。   コメント表示 ノードコメント欄の表示を切り替えます。\r    ブレークポイント ブレークポイントの設定を切り替えます。\r    アクション置き換え 他のアクションスクリプトに置き換えます。   デコレータ追加 デコレータを追加します。   サービス追加 サービスを追加します。   デコレータを新規貼り付け コピーしたデコレータを貼り付けます。   サービスを新規貼り付け コピーしたサービスを貼り付けます。   全て展開 ノードの挙動をすべて展開します。   全て折りたたみ ノードの挙動をすべて折りたたみます。   切り取り ノードを切り取ります。   コピー ノードをコピーします。   複製 ノードを複製します。   削除 ノードを削除します。    アクションのメニュー タイトルバーを右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     コピー コンポジットをコピーします。   値を貼り付け コピーしたコンポジットの値で上書きします。（同じ型のみ有効）   スクリプト編集 スクリプトエディタを開きます。   Editorスクリプト編集 Editorスクリプトを開きます(Editorスクリプトがある時のみ)    デコレータのメニュー タイトルバーを右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     上に移動 順番を上に移動します。   下に移動 順番を下に移動します。   コピー デコレータをコピーします。   値を貼り付け コピーしたデコレータの値で上書きします（同じ型のみ有効）   削除 デコレータを削除します。   スクリプト編集 スクリプトエディタを開きます。   Editorスクリプト編集 Editorスクリプトを開きます(Editorスクリプトがある時のみ)    サービスのメニュー タイトルバーを右クリックするか歯車アイコンをクリックするとメニューが表示されます。\n\r    項目 内容     上に移動 順番を上に移動します。   下に移動 順番を下に移動します。   コピー サービスをコピーします。   値を貼り付け コピーしたサービスの値で上書きします（同じ型のみ有効）   削除 サービスを削除します。   スクリプト編集 スクリプトエディタを開きます。   Editorスクリプト編集 Editorスクリプトを開きます(Editorスクリプトがある時のみ)    接続ラインのメニュー 接続ライン上を右クリックすると、メニューが表示されます。\n\r    項目 内容     親ノードへ移動 親ノードの位置へスクロールします。   子ノードへ移動 子ノードの位置へスクロールします。   切断 切断します。    デバッグメニュー ツールバーの「デバッグ」ボタンをクリックすると表示されます。\n\r    項目 内容     常にすべてのデータ値を表示 個々のデータラインの表示設定によらず常にデータ値を表示する   すべてのデータ値を表示 全てのデータラインの現在値を表示に変更します。   すべてのデータ値を非表示 全てのデータラインの現在値を非表示に変更します。   ブレークポイント設定 選択中ステートのブレークポイントを設定します。   ブレークポイント解除 選択中ステートのブレークポイントを解除します。   すべてのブレークポイントを解除 全てのステートのブレークポイントを解除します。    "
    },
    {
        "uri": "/manual/behaviourtree.html",
        "title": "ビヘイビアツリー",
        "tags": [],
        "description": "",
        "summary": "ここでは、ビヘイビアツリーの概要や使用方法について説明します。 ビヘイビアツリーとは？ ビヘイビアツリーの概要について説明します。 ノードの構成要",
        "content": "\r ここでは、ビヘイビアツリーの概要や使用方法について説明します。\n ビヘイビアツリーとは？\nビヘイビアツリーの概要について説明します。 ノードの構成要素\nビヘイビアツリーで使用するノードについて説明します。 ビヘイビアツリーの使い方\n詳しい使用方法について説明します。 各メニューについて\n各種メニューについて説明します。  "
    },
    {
        "uri": "/manual/scripting/dataflow/constraint.html",
        "title": "スロットの型制約",
        "tags": [],
        "description": "",
        "summary": "一部のスロットでは、属性を使用して接続可能な型に制約を設定できます。 スクリプト例 TestConstraintSlotBehaviourスクリ",
        "content": "\r 一部のスロットでは、属性を使用して接続可能な型に制約を設定できます。\nスクリプト例 TestConstraintSlotBehaviourスクリプトファイルを作成し、以下のコードを記述してください。\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestConstraintSlotBehaviour : StateBehaviour\r{\r[ClassExtends(typeof(AudioSource))]\rpublic InputSlotComponent audioSource = new InputSlotComponent();\r[ClassExtends(typeof(AudioClip))]\rpublic InputSlotUnityObject audioClip = new InputSlotUnityObject();\rpublic override void OnStateBegin()\r{\rAudioSource source_ = audioSource.GetValue\u0026lt;AudioSource\u0026gt;();\rif (source_ != null)\r{\rsource_.clip = audioClip.GetValue\u0026lt;AudioClip\u0026gt;();\r}\r}\r}    使用できる属性    クラス 属性     OutputSlotAny SlotTypeAttribute   InputSlotAny ClassTypeConstraintAttributeから派生したクラスSlotTypeAttribute   InputSlotComponent ClassTypeConstraintAttributeから派生したクラスSlotTypeAttribute指定の他、Componentクラスに制約される。   InputSlotUnityObject ClassTypeConstraintAttributeから派生したクラスSlotTypeAttribute指定の他、UnityEngine.Objectクラスに制約される。   FlexibleComponent ClassTypeConstraintAttributeから派生したクラスSlotTypeAttribute指定の他、Componentクラスに制約される。    "
    },
    {
        "uri": "/manual/scripting/behaviourinterface.html",
        "title": "挙動のインターフェイス",
        "tags": [],
        "description": "",
        "summary": "StateBehaviourやCalculator、ActionBehaviourなどのスクリプトにはいくつか使用できるインターフェイスがあ",
        "content": "StateBehaviourやCalculator、ActionBehaviourなどのスクリプトにはいくつか使用できるインターフェイスがあります。\n対象スクリプト 対象のスクリプトは以下の通りです。\n StateBehaviour Calculator ActionBehaviour Decorator Service  INodeBehaviourSerializationCallbackReceiver ノードの挙動スクリプトでシリアライズ時のコールバックを受け付けるためのインターフェイスです。\nスクリプトリファレンス: INodeBehaviourSerializationCallbackReceiver\nUnity標準のISerializationCallbackReceiverは内部的に使用しているため、コールバックを受けたい場合はこちらを使用して下さい。\n使用例 スクリプト 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40  using UnityEngine;\rusing System.Collections.Generic;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class ExampleSerializationCallback : StateBehaviour, INodeBehaviourSerializationCallbackReceiver\r{\rpublic List\u0026lt;int\u0026gt; _keys = new List\u0026lt;int\u0026gt; { 3, 4, 5 };\rpublic List\u0026lt;string\u0026gt; _values = new List\u0026lt;string\u0026gt; { \u0026#34;I\u0026#34;, \u0026#34;Love\u0026#34;, \u0026#34;Unity\u0026#34; };\rpublic Dictionary\u0026lt;int, string\u0026gt; _myDictionary = new Dictionary\u0026lt;int, string\u0026gt;();\rpublic void OnBeforeSerialize()\r{\r_keys.Clear();\r_values.Clear();\rforeach (var kvp in _myDictionary)\r{\r_keys.Add(kvp.Key);\r_values.Add(kvp.Value);\r}\r}\rpublic void OnAfterDeserialize()\r{\r_myDictionary = new Dictionary\u0026lt;int, string\u0026gt;();\rfor (int i = 0; i \u0026lt; Mathf.Min(_keys.Count, _values.Count); i++)\r_myDictionary.Add(_keys[i], _values[i]);\r}\rpublic override void OnStateBegin()\r{\rforeach (var kvp in _myDictionary)\r{\rDebug.Log(\u0026#34;Key: \u0026#34; + kvp.Key + \u0026#34; value: \u0026#34; + kvp.Value);\r}\r}\r}    INodeGraphContaiiner ノードの挙動スクリプトがサブグラフを内包している場合に使用するインターフェイスです。\nスクリプトリファレンス: INodeGraphContaiiner\n"
    },
    {
        "uri": "/manual/window/welcomewindow.html",
        "title": "ウェルカムウィンドウ",
        "tags": [],
        "description": "",
        "summary": "ウェルカムウィンドウ Arborをインポートした直後に表示されるウィンドウです。 使用方法やサポートフォーラムなどへのリンクが掲載されています。",
        "content": "\rウェルカムウィンドウ\n\r Arborをインポートした直後に表示されるウィンドウです。\n使用方法やサポートフォーラムなどへのリンクが掲載されています。\nウェルカムウィンドウを開く  Arborをインポートした直後や、自動表示をオフにしていなければプロジェクトを開いた直後に表示されます。 手動で開きたい場合は、メニューの「Window / Arbor / Welcome」を選択してください。  \r UI説明 言語設定 \r 表示する言語を設定します。\n次バージョンまで自動表示しない \r 次のバージョンまで自動的に表示しないトグルです。\nチェックすると、このプロジェクトを開いたときに表示されなくなります(Arborのバージョンが更新されるまで)。\nメニュー \r 公式サイトやドキュメントなどを開くメニューです。\nアイコンをクリックすると開きます。\nArbor Editorを開く \r Arbor Editorウィンドウを開きます。\n"
    },
    {
        "uri": "/manual/scripting/behaviourattribute.html",
        "title": "挙動の属性",
        "tags": [],
        "description": "",
        "summary": "StateBehaviourやCalculator、ActionBehaviourなどのスクリプトにはいくつか使用できる属性があります。 対象",
        "content": "StateBehaviourやCalculator、ActionBehaviourなどのスクリプトにはいくつか使用できる属性があります。\n対象スクリプト これから紹介する属性が使用できるスクリプトは以下の通りです。\n StateBehaviour Calculator ActionBehaviour Decorator Service  属性  AddBehaviourMenu\n挙動追加メニューでのパスを指定できる属性です。 HideBehaviour\n挙動追加メニューには表示しないようにする属性です。 BehaviourTitle\n挙動のタイトルバーに表示される名前を変更します。 BehaviourHelp\n挙動のタイトルバーに表示されるヘルプボタンをクリックすると開かれるURLを指定する属性です。  "
    },
    {
        "uri": "/manual/dataflow/invoke.html",
        "title": "メンバー呼び出し",
        "tags": [],
        "description": "",
        "summary": "任意の型のメンバーを呼び出す方法について説明します。 ここでは例としてArborFSMでの使用を想定して解説します。 InvokeMethod メソッドの呼び出しや、フ",
        "content": "\r 任意の型のメンバーを呼び出す方法について説明します。\nここでは例としてArborFSMでの使用を想定して解説します。\nInvokeMethod \r メソッドの呼び出しや、フィールドやプロパティに値を設定します。\nリファレンス : InvokeMethod\nInvokeMethodの追加  ステートの歯車アイコンをクリックし「挙動追加」を選択。 「Events / InvokeMethod」を選択。  \r InvokeMethodの設定  「Add New Event Type」ボタンをクリックし、呼び出したいタイミングを選択。 イベントの「＋」アイコンをクリックしてメンバー呼び出しデータを追加。 呼び出したい型とメンバーを設定。  型選択ウィンドウ メンバー選択ウィンドウ   \u0026lt;Target\u0026gt;を設定。  UnityオブジェクトであればFlexibleFieldで設定可能。 それ以外の型の場合はデータフローからの入力により受付。 staticメンバーの場合は設定項目なし。   引数の値を設定。  \r GetValue演算ノード \r フィールドやプロパティの値を取得し、データフローに出力します。\nリファレンス : InvokeMethod\nGetValueの追加  グラフ上を右クリックし、「演算ノード作成」を選択。 「Events / GetValue」を選択。  \r GetValueの設定  型とメンバーを設定。  型選択ウィンドウ メンバー選択ウィンドウ   \u0026lt;Target\u0026gt;を設定。  UnityオブジェクトであればFlexibleFieldで設定可能。 それ以外の型の場合はデータフローからの入力により受付。 staticメンバーの場合は設定項目なし。   値の出力スロットを接続。  \r リファクタリング 呼び出す型やメンバーの名前を変更したい場合、RenamedFrom属性を使用して新しい名前を以前の名前と関連付けすることで、参照切れを防げます。\n1 2 3 4 5 6 7 8 9 10 11 12  using UnityEngine;\rusing Arbor;\r[RenamedFrom(\u0026#34;Player\u0026#34;)]\rpublic class Character : MonoBehaviour\r{\r[RenamedFrom(\u0026#34;TakeDamage\u0026#34;)]\rpublic void InflictDamage(int damage)\r{\r// ...\r\t}\r}    以前の名前には名前空間を含める必要があります。\n上記の例などグローバル名前空間に定義している場合は必要ありません。\nUWPビルドの注意点 UWPビルドにてScripting Backendを「.NET」に設定している場合、型に指定したRenamedFromは動作しません。\nマネージコードストリッピング メンバー呼び出しはReflectionを使用して呼び出しているため、マネージコードストリッピングの設定によって呼び出し先メンバーが未使用コードとして削除されてしまう可能性があります。\nPreserve属性やlink.xmlファイルを設定して呼び出し先コードが削除されないように設定してください。\n詳しくは、Unityマニュアルのマネージコードストリッピングを参照してください。\n"
    },
    {
        "uri": "/manual/parametercontainer/globalparametercontainer.html",
        "title": "GlobalParameterContainer",
        "tags": [],
        "description": "",
        "summary": "GlobalParameterContainerはシーンを変更しても保持しておきたいパラメータがある場合に使用するコンポーネントです。 Glo",
        "content": "GlobalParameterContainerはシーンを変更しても保持しておきたいパラメータがある場合に使用するコンポーネントです。\nGlobalParameterContainerの追加 HierarchyウィンドウのCreateボタン  HierarchyウィンドウのCreateボタンをクリックするかウィンドウ内を右クリック Arbor/GlobalParameterContainerを選択 GlobalParameterContainerが追加されている状態のGameObjectが作成される  \r Inspectorウィンドウの”Add Component”ボタン  HierarchyウィンドウでGlobalParameterContainerを追加したいGameObjectを選択 Inspectorウィンドウの\u0026quot;Add Component\u0026quot;ボタンをクリック Arbor/GlobalParameterContainerを選択 GameObjectにGlobalParameterContainerが追加される  \r GlobalParameterContainerの設定  あらかじめシーン間で共有したいパラメータを設定したParameterContainerを作成し、Prefab化。\n\r  GlobalParameterContainerが追加されているGameObjectを選択。\nInspectorのPrefabに作成しておいたParameterContainerのPrefabを指定。\n\r   GlobalParameterContainer経由でパラメータを参照 ParameterReferenceのContainerフィールドにGlobalParameterContainerを指定するとパラメータが参照できるようになります。\n"
    },
    {
        "uri": "/manual/scripting/dataflow/datalink.html",
        "title": "DataLink属性",
        "tags": [],
        "description": "",
        "summary": "DataLink属性を使用することで、対応している型のInputSlotやFlexibleFieldがない場合でも、定数もしくはデータフロー",
        "content": "\r DataLink属性を使用することで、対応している型のInputSlotやFlexibleFieldがない場合でも、定数もしくはデータフローからの入力を受け付けられるようになります。\nスクリプトリファレンス : DataLink\nスクリプト例 ExampleDataLinkBehaviourスクリプトファイルを作成し、以下のコードを記述してください。\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class ExampleDataLinkBehaviour : StateBehaviour\r{\r[System.Serializable]\rpublic class ExampleData\r{\rpublic string name = \u0026#34;Test\u0026#34;;\rpublic float power = 100f;\r}\r[DataLink]\rpublic ExampleData exampleData;\r}    注意点  NodeBehaviourを継承したクラス(StateBehaviourやActionBehaviourなど)のフィールドでのみ使用できます。 配列やリストには使用できません。  "
    },
    {
        "uri": "/manual/subgraph.html",
        "title": "グラフの階層化",
        "tags": [],
        "description": "",
        "summary": "グラフの階層化を使えば、大まかな挙動と細かな挙動でグラフを分割できるため、柔軟なAIなどが組みやすくなります。 サブグラフの作成 サブグラフを作",
        "content": "グラフの階層化を使えば、大まかな挙動と細かな挙動でグラフを分割できるため、柔軟なAIなどが組みやすくなります。\n サブグラフの作成\nサブグラフを作成する方法について説明します。 グラフの引数\nグラフの引数について説明します。  "
    },
    {
        "uri": "/manual/parametercontainer.html",
        "title": "ParameterContainer",
        "tags": [],
        "description": "",
        "summary": "ParameterContainerはグラフ間でのデータ共有などを行うために使用するコンポーネントです。 GameObjectにParamet",
        "content": "ParameterContainerはグラフ間でのデータ共有などを行うために使用するコンポーネントです。\nGameObjectにParameterContainerを追加し、各種ある型のパラメータを設定します。\n ParameterContainerの追加\nGameObjectにParameterContainerコンポーネントを追加する方法について説明します。 パラメータの編集\nパラメータの追加や編集方法について説明します。 パラメータの種類\nパラメータの種類について説明します。 パラメータへのアクセス\nパラメータの値を取得や設定する方法について説明します。 GlobalParameterContainer\nシーンを跨いでも保持しておきたいパラメータについて説明します。 関連する組み込みスクリプト\nパラメータに関連する組み込みスクリプトの一例を紹介します。  "
    },
    {
        "uri": "/manual/parametercontainer/relatedscripts.html",
        "title": "関連する組み込みスクリプト",
        "tags": [],
        "description": "",
        "summary": "ここでは主にParameterContainerを参照する組み込みスクリプトを一部紹介します。 StateBehaviour スクリプト 説明 CalcParameter Parameterの値を演算",
        "content": "ここでは主にParameterContainerを参照する組み込みスクリプトを一部紹介します。\nStateBehaviour    スクリプト 説明     CalcParameter Parameterの値を演算して変更する。   SetBoolParameterFromUIToggle Toggleの値をParameterに設定する。   SetFloatParameterFromUISlider Sliderの値をParameterに設定する。   ParameterTransition Parameterの値を判定して遷移する。    Decorator    スクリプト 説明     ParameterCheck Parameterのチェック   ParameterConditionalLoop Parameterの条件によるループ。    他にも、FlexibleFieldを使用して値を取得する組み込みスクリプトが多数ありますのでリファレンスを参照してみてください。\nArborリファレンス\n"
    },
    {
        "uri": "/manual/scripting/parameterreference.html",
        "title": "パラメータの参照",
        "tags": [],
        "description": "",
        "summary": "パラメータをスクリプトから参照する方法について説明します。 ParameterReference ParameterReference関連クラスをフィールドに宣言することで、パラ",
        "content": "パラメータをスクリプトから参照する方法について説明します。\n ParameterReference\nParameterReference関連クラスをフィールドに宣言することで、パラメータを参照できるようになります。 FlexibleField\nFlexibleField関連クラスを使用すると、固定値の指定やパラメータ参照もしくはデータフローからの入力を切り替えて参照できます。 参照する型の制約\n一部のフィールドでは、属性を指定することで参照する型を制約することができます。  "
    },
    {
        "uri": "/manual/dataflow.html",
        "title": "データフロー",
        "tags": [],
        "description": "",
        "summary": "Arborにはグラフのノード間でデータを受け渡すための機能が備わっています。 データフローとは？ データフローの概要について説明します。 データフ",
        "content": "Arborにはグラフのノード間でデータを受け渡すための機能が備わっています。\n データフローとは？\nデータフローの概要について説明します。 データフローの使い方\nデータフローの使い方について説明します。 演算ノード\nデータフロー専用の演算用ノードについて説明します。 リスト(配列)\nデータフローでリスト(配列)を利用する方法について説明します。 メンバー呼び出し\nスクリプトを作成せずに既存の型のメンバーを呼び出す方法について説明します。  スクリプティング 自作したスクリプトからもデータフローを使用できます。\n詳しくは、「スクリプティング : データフロー」を参照してください。\nスクリプティング : データフロー\n"
    },
    {
        "uri": "/manual/scripting/dataflow.html",
        "title": "データフロー",
        "tags": [],
        "description": "",
        "summary": "データフローの入出力をスクリプトから行う方法について説明します。 出力スロット OutpotSlotIntなどの出力スロットを宣言することでデー",
        "content": "データフローの入出力をスクリプトから行う方法について説明します。\n 出力スロット\nOutpotSlotIntなどの出力スロットを宣言することでデータ出力ができます。 入力スロット\nInputSlotIntなどの入力スロットを宣言することでデータ出力ができます。 FlexibleField\n入力スロットだけでなく、固定値やパラメータも扱いたい場合はFlexibleFieldが便利です。 スロットの型制約\n一部のスロットでは、属性を使用して接続可能な型に制約を設定できます。 DataLink属性\nDataLink属性を使用することで、対応している型のInputSlotやFlexibleFieldがない場合でも、定数もしくはデータフローからの入力を受け付けられるようになります。  カスタマイズ データスロットの作成 自作したクラスのデータスロットも作成できます。\n詳しくは、「スクリプティング : データスロット」を参照してください。\nスクリプティング : データスロット\nVariable パラメータも作成する場合は、Variable Generatorを使用すると楽に作成できます。\n詳しくは、「スクリプティング : Variable」を参照してください。\nスクリプティング : Variable\n演算ノード 演算ノードに使用するスクリプトも作成できます。\n詳しくは、「スクリプティング : 演算ノード」を参照してください。\nスクリプティング : 演算ノード\n"
    },
    {
        "uri": "/manual/scripting/dataslot.html",
        "title": "データスロット",
        "tags": [],
        "description": "",
        "summary": "ここでは、自作クラスのデータスロットを作成する方法を説明します。 例として簡単なプレイヤーデータの作成を通してデータをやり取りするまでの作り方",
        "content": "ここでは、自作クラスのデータスロットを作成する方法を説明します。\n例として簡単なプレイヤーデータの作成を通してデータをやり取りするまでの作り方を説明していきます。\nPlayerDataスクリプトファイルの作成 スクリプトファイルを作成していきます。\n Projectウィンドウの右クリックメニューから「Create \u0026gt; C# Script」を選択。 今回は名前をPlayerDataとします。  PlayerData.csには以下のように記述します。\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20  using UnityEngine; using System.Collections; using Arbor; [System.Serializable] public class PlayerData { public int maxHP; public int hp; } [System.Serializable] public class OutputSlotPlayerData : OutputSlot\u0026lt;PlayerData\u0026gt; { } [System.Serializable] public class InputSlotPlayerData : InputSlot\u0026lt;PlayerData\u0026gt; { }    コードの解説 PlayerDataクラスの作成 今回は単純に最大HPと現在HPを持ったクラスを作成しています。\nOutputSlotPlayerDataクラスの作成 PlayerDataクラスを出力するためのクラスを作成しています。\nすべての処理はOutputSlot\u0026lt;T\u0026gt;に用意されているため、特に中身は記述する必要はありません。\nジェネリッククラスがシリアライズできないというUnityの仕様を回避するために用意しています。\nInputSlotPlayerDataクラスの作成 PlayerDataクラスを入力するためのクラスを作成しています。\nこちらもInputSlot\u0026lt;T\u0026gt;に必要な処理が用意されているため、特に中身を記述する必要はありません。\n"
    },
    {
        "uri": "/manual/scripting.html",
        "title": "スクリプティング",
        "tags": [],
        "description": "",
        "summary": "Arborはスクリプトを記述することで自由にカスタマイズできます。 StateBehaviour ステートに割り当てるスクリプトについて説明します。 BehaviourTree BehaviourT",
        "content": "Arborはスクリプトを記述することで自由にカスタマイズできます。\n StateBehaviour\nステートに割り当てるスクリプトについて説明します。 BehaviourTree\nBehaviourTreeのノードに割り当てるスクリプトについて説明します。 演算ノード\n演算ノードに割り当てるスクリプトについて説明します。 挙動のインターフェイス\n挙動スクリプトで使用できるインターフェイスについて説明します。 挙動の属性\n挙動スクリプトに設定できる属性について説明します。 パラメータの参照\nパラメータをスクリプトから参照する方法について説明します。 データフロー\nデータフローをスクリプトから参照する方法について説明します。 データスロット\nデータスロットを自作する方法について説明します。 Variable\nパラメータを自作する方法について説明します。  エディタ拡張 Unityで使用可能なインスペクタ拡張やPropertyDrawerなどがStateBehaviourにも使用できる\n エディタの多言語対応\nエディタ拡張する際にArborの多言語対応を行う方法について説明します。  "
    },
    {
        "uri": "/manual/scripting/variable.html",
        "title": "Variable",
        "tags": [],
        "description": "",
        "summary": "ここでは、自作パラメータをParameterContainerに登録する方法を説明します。 Variableスクリプトファイルの作成 Variable Gene",
        "content": "ここでは、自作パラメータをParameterContainerに登録する方法を説明します。\nVariableスクリプトファイルの作成 Variable Generatorによるスクリプトの生成 自作パラメータ用スクリプトを作成します。\n Projectウィンドウの右クリックメニューから「Create \u0026gt; Arbor \u0026gt; Variable C# Script」を選択。\n\r  Variale Generatorウィンドウの「Variable Name」フィールドにパラメータクラス名を入力 「Create」ボタンを押してスクリプト作成。\n\r  使用できない名前の場合はエラーボックスが表示されるため、Variable Nameを修正してください。 OpenEditorチェックボックスがチェックされていると、「Create」ボタン押下後にスクリプトエディタが開きます。    作成例 「Variable Name」にEnemyInfoと入力し、「Create」ボタンを押して作成されたスクリプト例\nEnemyInfoVariable.cs 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; [System.Serializable] public class EnemyInfo { // Declare Serialize Fields } [System.Serializable] public class FlexibleEnemyInfo : FlexibleField\u0026lt;EnemyInfo\u0026gt; { public FlexibleEnemyInfo(EnemyInfo value) : base(value) { } public FlexibleEnemyInfo(AnyParameterReference parameter) : base(parameter) { } public FlexibleEnemyInfo(InputSlotAny slot) : base(slot) { } public static explicit operator EnemyInfo(FlexibleEnemyInfo flexible) { return flexible.value; } public static explicit operator FlexibleEnemyInfo(EnemyInfo value) { return new FlexibleEnemyInfo(value); } } [System.Serializable] public class InputSlotEnemyInfo : InputSlot\u0026lt;EnemyInfo\u0026gt; { } [System.Serializable] public class OutputSlotEnemyInfo : OutputSlot\u0026lt;EnemyInfo\u0026gt; { } [AddComponentMenu(\u0026#34;\u0026#34;)] public class EnemyInfoVariable : Variable\u0026lt;EnemyInfo\u0026gt; { }    EnemyInfoListVariable.cs 1 2 3 4 5 6 7 8 9  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; [AddComponentMenu(\u0026#34;\u0026#34;)] public class EnemyInfoListVariable : VariableList\u0026lt;EnemyInfo\u0026gt; { }    解説  EnemyInfo\n自作するパラメータのクラス。\nシリアライズ用フィールドを追加することで、ParameterContainerで自作パラメータを設定できるようになります。 FlexibleEnemyInfo\nConstant、Parameter、Calculatorを切り替えて参照できるようにするためのクラス。 InputSlotEnemyInfo\nEnemyInfoの入力スロット用クラス。 OutputSlotEnemyInfo\nEnemyInfoの出力スロット用クラス。 EnemyInfoVariable\nParameterContainerへ登録するためのVariableクラス。\nクラス名とスクリプトファイル名が一致している必要があります。 EnemyInfoListVariable\nParameterContainerへ登録するためのVariableListクラス。\nクラスメイトスクリプトファイル名が一致している必要があります。  フィールドの追加 生成したスクリプトにフィールドを追加します。\n例として、EnemyInfoにいくつかフィールドを追加してみます。\n1 2 3 4 5 6 7  [System.Serializable] public class EnemyInfo { // Declare Serialize Fields \tpublic string displayName; public Sprite icon; }    ParameterContainerへの追加 作成したVariableをParameterContainerへ追加します。\n あらかじめParameterContainerを作成しておいてください。 「＋」ボタンを押し、「Variable \u0026gt; 作成したVariable名」を選択。\n\r  パラメータが追加される\n\r   Variableパラメータへの参照 FlexibleField 生成したスクリプトファイルに定義されているFlexible+Variable NameのクラスをStateBehaviourなどに持たせることで参照できます。\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; [AddComponentMenu(\u0026#34;\u0026#34;)] public class EnemyInfoBehaviour : StateBehaviour { public FlexibleEnemyInfo enemyInfo; // Use this for enter state \tpublic override void OnStateBegin() { EnemyInfo value = enemyInfo.value; Debug.Log(value.displayName); } }    \r AnyParameterReference Parameterを直接参照する場合はAnyParameterReferenceを使用します。\n1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22  using UnityEngine; using System.Collections; using System.Collections.Generic; using Arbor; [AddComponentMenu(\u0026#34;\u0026#34;)] public class EnemyInfoBehaviour2 : StateBehaviour { [ClassExtends(typeof(EnemyInfo))] public AnyParameterReference enemyInfo = new AnyParameterReference(); // Use this for enter state \tpublic override void OnStateBegin() { Parameter enemyInfoParameter = enemyInfo.parameter; if (enemyInfoParameter != null) { EnemyInfo value = enemyInfoParameter.value as EnemyInfo; Debug.Log(value.displayName); } } }    \r "
    },
    {
        "uri": "/manual/window.html",
        "title": "ウィンドウ",
        "tags": [],
        "description": "",
        "summary": "各ウィンドウについて説明します。 挙動選択ウィンドウ 挙動を選択するウィンドウ 型選択ウィンドウ 型を選択するウィンドウ メンバー選択ウィンドウ メンバ",
        "content": "各ウィンドウについて説明します。\n 挙動選択ウィンドウ\n\r挙動を選択するウィンドウ\n\r  型選択ウィンドウ\n\r型を選択するウィンドウ\n\r  メンバー選択ウィンドウ\n\rメンバーを選択するウィンドウ\n\r  ウェルカムウィンドウ\n\rArborをインポートした直後に表示されるウィンドウ\n\r   "
    },
    {
        "uri": "/manual/scripting/localization.html",
        "title": "エディタの多言語対応",
        "tags": [],
        "description": "",
        "summary": "挙動スクリプトで使用できる属性やエディタ拡張では多言語対応ができます。 多言語ファイルの準備 多言語対応を行うには、各言語ファイルを追加する必要",
        "content": "挙動スクリプトで使用できる属性やエディタ拡張では多言語対応ができます。\n多言語ファイルの準備 多言語対応を行うには、各言語ファイルを追加する必要があります。\nまた、言語ファイルを配置するフォルダの登録も行います。\n言語ファイルはエディタでしか使用できないため、Editorフォルダの中に配置します。\nLanguagePath 言語ファイルを配置するフォルダを登録するには、LanguagePathアセットをフォルダに配置します。\n 配置するフォルダをProjectウィンドウで選択し右クリック。 「Create / Arbor / Editor / LanguagePath」を選択。 名前は特に制限がないため、好きな名前を付けてください。  \r 言語ファイルの作成 LanguagePathアセットを配置したフォルダに、「言語名.txt」のファイルを作成すると言語ファイルとして認識されます。\n「言語名」はSystemLanguage列挙子の値と同名である必要があります。\nUnity ScriptReference : SystemLanguage\n言語ファイルの記入 言語ファイルでは、1行ごとに「ワードのキー: 表示する文字列」の形式で記入していきます。\nまた、行頭が「//」の場合はコメントとみなされ、その行は無視されます。\n例えば、Japanese.txtを作成し、以下のように記入します。 1 2 3 4  // ボスの挙動関連\rMenu_ExampleBossAttack: 多言語対応/ボスの攻撃\rExampleBossAttack: ボスの攻撃\rExampleBossDefense: ボスの防御  \n続いて、English.txtを作成し、以下のように記入します。 1 2 3 4  // Boss behavior related\rMenu_ExampleBossAttack: Localization/Boss\u0026#39;s attack\rExampleBossAttack: Boss\u0026#39;s attack\rExampleBossDefense: Boss\u0026#39;s defense  \nフォルダ構成の例  Assets  Editor  Languages  LanguagePath.asset English.txt Japanese.txt        多言語ワードの参照 エディタ拡張からの参照 エディタ拡張から参照する場合は、ArborEditor.Localization.GetWord()やGetTextContent()を使用します。\nエディタ拡張のスクリプト例 TestLocalizationBehaviour.cs 1 2 3 4 5 6 7  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\rpublic class TestLocalizationBehaviour : StateBehaviour\r{\r}    TestLocalizationBehaviourEditor.cs 1 2 3 4 5 6 7 8 9 10 11 12  using UnityEditor;\rusing ArborEditor;\r[CustomEditor(typeof(TestLocalizationBehaviour))]\rpublic class TestLocalizationBehaviourEditor : Editor\r{\rpublic override void OnInspectorGUI()\r{\rEditorGUILayout.LabelField(Localization.GetWord(\u0026#34;ExampleBossAttack\u0026#34;));\rEditorGUILayout.LabelField(Localization.GetWord(\u0026#34;ExampleBossDefense\u0026#34;));\r}\r}    エディタ拡張の表示例 \r 挙動の属性での参照 AddBehaviourMenuやBehaviourTitleでlocalizationフィールドをtrueにすると、言語ファイルから参照するようになります。\n属性を使ったスクリプト例 1 2 3 4 5 6 7 8 9  using UnityEngine;\rusing Arbor;\r[AddComponentMenu(\u0026#34;\u0026#34;)]\r[AddBehaviourMenu(\u0026#34;Menu_ExampleBossAttack\u0026#34;,localization=true)]\r[BehaviourTitle(\u0026#34;ExampleBossAttack\u0026#34;,localization =true)]\rpublic class ExampleBossAttackBehaviour : StateBehaviour\r{\r}    属性を使った表示例 英語 \r 日本語 \r "
    },
    {
        "uri": "/manual/extra.html",
        "title": "エクストラ",
        "tags": [],
        "description": "",
        "summary": "Arborをさらに便利に利用する特殊な機能を紹介します。 PackageManagerでの利用",
        "content": "Arborをさらに便利に利用する特殊な機能を紹介します。\n PackageManagerでの利用  "
    },
    {
        "uri": "/manual/updateguide.html",
        "title": "アップデートガイド",
        "tags": [],
        "description": "",
        "summary": "最新バージョンへ更新する場合、下記のガイドを参照してください。 更新手順 更新前に必ずプロジェクトのバックアップを取ってください。 既存のシーンを",
        "content": "最新バージョンへ更新する場合、下記のガイドを参照してください。\n更新手順  更新前に必ずプロジェクトのバックアップを取ってください。 既存のシーンを開いている場合は、メニューの「File / New Scene」からシーンを新規作成しておきます。 Arbor　Editorウィンドウを開いている場合は一旦閉じておきます。 既にインポートされているArborフォルダを削除。 Arborの新バージョンをインポート。  各バージョン更新ガイド  Arbor 3.7への更新 Arbor 3.6への更新  "
    },
    {
        "uri": "/",
        "title": "Home",
        "tags": [],
        "description": "",
        "summary": "Arborを使って、ゲームの進行やAIなどの状態遷移図を視覚的に作成していきましょう。 ArborはUnity Asset Storeから購入できます。 Arbor",
        "content": "Arborを使って、ゲームの進行やAIなどの状態遷移図を視覚的に作成していきましょう。\nArborはUnity Asset Storeから購入できます。\n Arbor Documentationでは、Arborの使い方を学ぶ支援を行っています。\nマニュアルを一通り読んだり、必要になったところだけリファレンスとして使うこともできます。\nArbor を初めて使うのであれば、マニュアル : はじめに をご覧ください。\nドキュメント  マニュアル\nArborの主な使い方について学ぶことができます。 Arbor リファレンス\nArborで使用するコンポーネントなどについてのリファレンスが掲載されています。 スクリプトリファレンス\nArborで使用する主なスクリプトのリファレンスが掲載されています。  マニュアル以外の情報源  チュートリアル\nArborの使い方を実践形式で学ぶことができます。 Arborフォーラム\n使い方について質問したり、機能要望を投稿できます。  "
    },
    {
        "uri": "/search.html",
        "title": "Search",
        "tags": [],
        "description": "",
        "summary": "",
        "content": ""
    },
    {
        "uri": "/manual.html",
        "title": "マニュアル",
        "tags": [],
        "description": "",
        "summary": "ここではArborについての使用方法や詳しいリファレンスを掲載しています。 詳しくは以下リンクより参照してください。 マニュアルではUnity2",
        "content": "ここではArborについての使用方法や詳しいリファレンスを掲載しています。 詳しくは以下リンクより参照してください。\nマニュアルではUnity2019.4を使用して説明しています。\nまた、Unityエディタは日本語化せず英語版での表記となります。\nUnityのバージョンや設定によっては見た目が異なる場合がありますのでご注意ください。\n はじめに\n初めてArborを利用する方向けに基本的な概要と操作方法を説明しています。 ArborEditorウィンドウ\nArborEditorウィンドウについて説明しています。 ステートマシン\nステートマシンについて説明しています。 ビヘイビアツリー\nビヘイビアツリーについて説明しています。 グラフの階層化\nグラフの階層化について説明しています。 ParameterContainer\nParameterContainerについて説明しています。 データフロー\nデータスロットによるデータの受け渡しについて説明しています。 スクリプティング\nスクリプトを使用したカスタマイズ方法について解説します。 ウィンドウ\n各ウィンドウについて説明します。 エクストラ\nArborをさらに便利に利用する特殊な機能を紹介します。 アップデートガイド\n最新バージョンに更新する場合は、このガイドを参照してください。 Arborリファレンス\n主なComponentや組み込みBehaviour、組み込みCalculatorについてのリファレンス スクリプトリファレンス\nスクリプトに関するリファレンス  "
    },
    {
        "uri": "/categories.html",
        "title": "Categories",
        "tags": [],
        "description": "",
        "summary": "",
        "content": ""
    },
    {
        "uri": "/tags.html",
        "title": "Tags",
        "tags": [],
        "description": "",
        "summary": "",
        "content": ""
    }
];