var class_arbor_1_1_color_list_parameter_reference =
[
    [ "value", "class_arbor_1_1_color_list_parameter_reference.html#ad36cab532c02909c6f55431398367b59", null ]
];