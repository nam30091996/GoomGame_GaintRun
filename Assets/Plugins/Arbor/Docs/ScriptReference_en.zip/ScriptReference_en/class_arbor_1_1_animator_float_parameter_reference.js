var class_arbor_1_1_animator_float_parameter_reference =
[
    [ "Get", "class_arbor_1_1_animator_float_parameter_reference.html#ae843a9d94bd34236b8a23ee0c89db1ea", null ],
    [ "Set", "class_arbor_1_1_animator_float_parameter_reference.html#ab9ba40c93e2c1a20a1bb9dbdb42fb877", null ],
    [ "Set", "class_arbor_1_1_animator_float_parameter_reference.html#a99c411e689fef70f8000b46c916784ab", null ]
];