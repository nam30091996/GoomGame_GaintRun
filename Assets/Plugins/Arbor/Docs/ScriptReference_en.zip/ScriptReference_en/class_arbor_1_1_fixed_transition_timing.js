var class_arbor_1_1_fixed_transition_timing =
[
    [ "FixedTransitionTiming", "class_arbor_1_1_fixed_transition_timing.html#a4ea02253497a20cbca0baffe43716be2", null ],
    [ "transitionTiming", "class_arbor_1_1_fixed_transition_timing.html#a0b47bfd232161df512fd5128df1b4f40", null ]
];