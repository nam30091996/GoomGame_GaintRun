var class_arbor_1_1_add_calculator_menu =
[
    [ "AddCalculatorMenu", "class_arbor_1_1_add_calculator_menu.html#a67a1e58d0c87df169da296931d795f7d", null ],
    [ "menuName", "class_arbor_1_1_add_calculator_menu.html#a460fe877fc1e21d7024f337327d46caa", null ]
];