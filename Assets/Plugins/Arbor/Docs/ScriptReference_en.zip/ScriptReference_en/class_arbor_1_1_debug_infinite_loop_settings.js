var class_arbor_1_1_debug_infinite_loop_settings =
[
    [ "enableBreak", "class_arbor_1_1_debug_infinite_loop_settings.html#acef7188395f101cd29c94cabcd87de5b", null ],
    [ "enableLogging", "class_arbor_1_1_debug_infinite_loop_settings.html#ac068d0e6cb88339c481e522c9795e173", null ],
    [ "maxLoopCount", "class_arbor_1_1_debug_infinite_loop_settings.html#a033313250ff4c8f98803f80105d1a1b2", null ]
];