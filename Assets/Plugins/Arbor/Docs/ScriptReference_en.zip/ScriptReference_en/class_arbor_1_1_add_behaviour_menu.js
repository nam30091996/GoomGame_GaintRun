var class_arbor_1_1_add_behaviour_menu =
[
    [ "AddBehaviourMenu", "class_arbor_1_1_add_behaviour_menu.html#a87c0525d13fb35600c8c4c4765d81d54", null ],
    [ "localization", "class_arbor_1_1_add_behaviour_menu.html#aed7fbb16881c4a1dbcd683f8bf223b91", null ],
    [ "menuName", "class_arbor_1_1_add_behaviour_menu.html#a460fe877fc1e21d7024f337327d46caa", null ]
];