var class_arbor_1_1_internal_1_1_document_type =
[
    [ "DocumentType", "class_arbor_1_1_internal_1_1_document_type.html#ae728597d0413963b27dcf4fc4f70bb29", null ],
    [ "type", "class_arbor_1_1_internal_1_1_document_type.html#a4f922e6f5e09574dccd4cdd19e26da9d", null ]
];