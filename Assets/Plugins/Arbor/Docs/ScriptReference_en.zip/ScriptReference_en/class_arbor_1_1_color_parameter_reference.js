var class_arbor_1_1_color_parameter_reference =
[
    [ "value", "class_arbor_1_1_color_parameter_reference.html#a180d126311be52c159011af1174b4d2d", null ]
];