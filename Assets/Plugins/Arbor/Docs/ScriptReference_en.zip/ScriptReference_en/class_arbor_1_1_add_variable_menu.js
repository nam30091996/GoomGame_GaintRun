var class_arbor_1_1_add_variable_menu =
[
    [ "AddVariableMenu", "class_arbor_1_1_add_variable_menu.html#a44f6879a1a597beb904a45d2f221d430", null ],
    [ "menuName", "class_arbor_1_1_add_variable_menu.html#a460fe877fc1e21d7024f337327d46caa", null ]
];