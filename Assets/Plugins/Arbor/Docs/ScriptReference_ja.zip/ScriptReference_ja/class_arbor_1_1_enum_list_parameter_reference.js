var class_arbor_1_1_enum_list_parameter_reference =
[
    [ "GetValue< TEnum >", "class_arbor_1_1_enum_list_parameter_reference.html#aa88439dcb81a65ac98efeadcb362063e", null ],
    [ "SetValue< TEnum >", "class_arbor_1_1_enum_list_parameter_reference.html#a357030a17552d06d8f5f35c9887f0040", null ]
];