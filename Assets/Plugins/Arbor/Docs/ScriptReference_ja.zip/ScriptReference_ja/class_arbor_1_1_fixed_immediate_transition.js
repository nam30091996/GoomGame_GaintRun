var class_arbor_1_1_fixed_immediate_transition =
[
    [ "FixedImmediateTransition", "class_arbor_1_1_fixed_immediate_transition.html#a717ff83b94272d6740e9903e623fb0ff", null ],
    [ "immediate", "class_arbor_1_1_fixed_immediate_transition.html#ab7e91bdbb310a07cc7d6b63438b3eb08", null ]
];