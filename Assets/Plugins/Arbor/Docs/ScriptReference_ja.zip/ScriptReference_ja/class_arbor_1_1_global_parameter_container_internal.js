var class_arbor_1_1_global_parameter_container_internal =
[
    [ "instance", "class_arbor_1_1_global_parameter_container_internal.html#afcb8cb2d2d931543eaa52af1325987d7", null ],
    [ "prefab", "class_arbor_1_1_global_parameter_container_internal.html#a41173c5e76a50379f22ac296bd39b8f1", null ]
];