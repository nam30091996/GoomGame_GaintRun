var class_arbor_1_1_internal_1_1_document_label =
[
    [ "DocumentLabel", "class_arbor_1_1_internal_1_1_document_label.html#ac36dbfe35df7ec85e9356532c5866815", null ],
    [ "name", "class_arbor_1_1_internal_1_1_document_label.html#a8ccf841cb59e451791bcb2e1ac4f1edc", null ]
];